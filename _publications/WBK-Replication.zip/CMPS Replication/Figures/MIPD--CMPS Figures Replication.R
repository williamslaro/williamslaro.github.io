#######################################################################################
### R file to replicate the figures in the manuscript introducing the Most Important Problem Dataset (MIPD)
###
### Created: 9-1-16
### Modified: 
###
#######################################################################################

library(foreign)
library(ggplot2)
library(lattice)
library(fields)
library(splines)
library(MASS)
library(scales)
library(gridExtra)
library(compactr)
library(gtable)
library(grid)

### Set up working directory
setwd("")


#######################################################################################
### Figure 1: Number of surveys and survey respondents by year, 1939-2015
#######################################################################################
s = read.dta("Figures/Sample Comparisons.dta", convert.underscore=TRUE)

s1 <- ggplot(s, aes(year, no.s2))
s1 <- s1 + geom_point() + geom_line() + ylab("Number of Surveys") + xlab("")
s1 <- s1 + theme(panel.background = element_blank(), axis.line = element_line(colour = "black"), panel.grid.minor = element_line(color = "lightgrey"))

s2 <- ggplot(s, aes(year, total.obs2))
s2 <- s2 + geom_point() + geom_line() + ylab("Survey Respondents") + xlab("")
s2 <- s2 + theme(panel.background = element_blank(), axis.line = element_line(colour = "black"), panel.grid.minor = element_line(color = "lightgrey"))

grid.newpage()
pushViewport(viewport(layout = grid.layout(2,1)))
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(s1, vp = vplayout(1, 1))
print(s2, vp = vplayout(2, 1))

#######################################################################################
### Figure 2: Foreign Policy Issue Importance, 1939-2015
#######################################################################################
agg = read.dta("MIPD Aggregate--CMPS.dta", convert.underscore=TRUE)
c = read.csv("Figures/control.csv")

y1 = c(rep(0, 6))
y2 = c(rep(80, 6))

d = data.frame(lab = c('Cuban Missile Crisis', 'Iran Hostage Crisis', 'Invasion of Grenada', 'Iraqi Invasion of Kuwait', 'September 11', 'Troop Surge'), 
	xtxt = c(1017, 7247, 8698, 11171, 15594, 17176), 
	ytxt = c(rep(90, 6)))

fp <- ggplot(subset(agg, openended == "1. Yes" & problem == "Foreign Policy" & pid == "Total"))
fp <- fp + stat_smooth(method = "lm", formula = y ~ ns(x, 9), aes(x=fw.start2, y=perc)) 
fp <- fp + geom_point(aes(x=fw.start2, y=perc), shape = 20)
fp <- fp + geom_rect(data=subset(c, !is.na(endwar2)), mapping = aes(xmin=startwar, xmax=endwar2, ymin=y1, ymax=y2), fill="darkred", alpha = 0.2)
fp <- fp + geom_text(data=d, aes(label = lab, x = xtxt, y = ytxt), angle = 90, vjust = 0, size=3, family="Times")
fp <- fp + scale_x_continuous(breaks=c(-7305, -3652, 0, 3653, 7305, 10958, 14610, 18263), labels=c("1940", "1950", "1960", "1970", "1980", "1990", "2000", "2010"))
fp <- fp + scale_y_continuous(limits=c(0, 100))
fp <- fp + ylab("Most Important Problem (%)") + xlab("")
fp <- fp + theme(panel.background = element_blank(), axis.line = element_line(colour = "black"), panel.grid.minor = element_line(color = "lightgrey"))
fp



#######################################################################################
### Figure 3: Issue Importance of the Economy and Foreign Policy to All Other Problems, 1939-2015
#######################################################################################
rel <- subset(agg, openended == "1. Yes" & pid == "Total")

r <- ggplot(data=rel)
r <- r + stat_smooth(aes(group = problem, fill = problem, linetype = problem, x=fw.start2, y=perc), size = 1.25, method = "lm", formula = y ~ ns(x, 9)) 
r <- r + geom_rect(data=c, mapping = aes(xmin=startrec, xmax=endrec, ymin=c(rep(0, 12)), ymax=c(rep(80, 12))), fill="darkred", alpha = 0.2)
r <- r + ylab("Most Important Problem (%)") + xlab("")
r <- r + scale_y_continuous(limits=c(0, 80))
r <- r + scale_fill_manual(values = c("gray70", "gray40", "gray10"))
r <- r + scale_x_continuous(breaks=c(-7305, -3652, 0, 3653, 7305, 10958, 14610, 18263), labels=c("1940", "1950", "1960", "1970", "1980", "1990", "2000", "2010"))
r <- r + theme(legend.title=element_blank(), legend.position="bottom", panel.background = element_blank(), axis.line = element_line(colour = "black"), panel.grid.minor = element_line(color = "lightgrey"))
r


#######################################################################################
### Figure 4: Foreign Policy Issue Importance between Republicans and Democrats, 1939-2015
#######################################################################################
y1 = c(rep(0, 4))
y2 = c(rep(80, 4))

piddata <- subset(agg, openended == "1. Yes" & problem == "Foreign Policy" & (pid == "Democrat" | pid == "Republican"))

fpd <- ggplot(data = piddata, aes(x=fw.start2, y=perc)) 
fpd <- fpd + facet_grid(. ~ pid)
fpd <- fpd + geom_point(data = subset(piddata, pid == "Democrat"), shape = 17)
fpd <- fpd + geom_point(data = subset(piddata, pid == "Republican"), shape = 19)
fpd <- fpd + stat_smooth(data = subset(piddata, pid == "Republican"), method = "lm", formula = y ~ ns(x, 9), fill = "blue")
fpd <- fpd + stat_smooth(data = subset(piddata, pid == "Democrat"), method = "lm", formula = y ~ ns(x, 9), fill = "red")
fpd <- fpd + scale_x_continuous(breaks=c(-7305, -3652, 0, 3653, 7305, 10958, 14610, 18263), labels=c("1940", "1950", "1960", "1970", "1980", "1990", "2000", "2010"))
fpd <- fpd + scale_y_continuous(limits=c(0, 80))
fpd <- fpd + ylab("Most Important Problem (%)") + xlab("")
fpd <- fpd + theme(legend.title=element_blank(), legend.position="bottom", panel.background = element_blank(), axis.line = element_line(colour = "black"), panel.grid.minor = element_line(color = "lightgrey"))
fpd




#######################################################################################
### Figure 5: Foreign Policy Issue Importance among Conservatives and Liberals, 1970-2015
#######################################################################################
y1 = c(rep(0, 3))
y2 = c(rep(70, 3))

ideodata <- subset(agg, fw.start >= 3653 & openended == "1. Yes" & problem == "Foreign Policy" & (ideology == "Liberal" | ideology == "Conservative"))

fpd <- ggplot(data = ideodata, aes(x = fw.start2, y = perc))
fpd <- fpd + facet_grid(. ~ ideology)
fpd <- fpd + geom_point(data = subset(ideodata, ideology == "Liberal"), shape = 17)
fpd <- fpd + geom_point(data = subset(ideodata, ideology == "Conservative"), shape = 19)
fpd <- fpd + stat_smooth(data = subset(ideodata, ideology == "Liberal"), method = "lm", formula = y ~ ns(x, 9), fill = "blue")
fpd <- fpd + stat_smooth(data = subset(ideodata, ideology == "Conservative"), method = "lm", formula = y ~ ns(x, 9), fill = "red")
fpd <- fpd + scale_y_continuous(limits=c(0, 70))
fpd <- fpd + scale_x_continuous(breaks=c(3653, 7305, 10958, 14610, 18263), labels=c("1970", "1980", "1990", "2000", "2010"))
fpd <- fpd + ylab("Most Important Problem (%)") + xlab("")
fpd <- fpd + theme(legend.title=element_blank(), legend.position="bottom", panel.background = element_blank(), axis.line = element_line(colour = "black"), panel.grid.minor = element_line(color = "lightgrey"))
fpd

