******************************************************************************************************
*** This folder contains the files needed to replicate the aggregate-level analysis in "the 'Most Important Problem' Dataset (MIPD): A New Dataset on American Issue Importance", Colton Heffington, Brandon Beomseob Park and Laron K. Williams, Conflict Management and Peace Science.
***
*** Created: 12-6-16
***
*** NOTE: any questions, please contact Laron K. Williams, williamslaro@missouri.edu.
******************************************************************************************************

Before executing these replication files, you need to download the individual-level dataset from Roper Center at goo.gl/GG9d87.  If you are not affiliated with a member institution, you can request the data on a case-by-case basis by emailing data-services@ropercenter.org.  The dataset is named �USMISC2015-MIPD_ind.dta�.  


The folder contains the following files:

1) MIPD Codebook�Release 1.0.pdf: Codebook for the individual-level MIP dataset (first release).  

2) Generate Aggregate MIPD--CMPS.do: Stata do file which takes the individual dataset (referenced above) and generates the aggregate MIP percentages.  This creates the �MIPD Aggregate�CMPS.dta� file.

3) MIPD Replication--CMPS.do: Stata do file containing the correlations for the foreign policy and economy MIP percentages.

4) MIPD--CMPS Figures Replication.R: R script file that uses the MIPD Aggregate--Version 1.0.dta and control.csv to create the figures in the manuscript.

5) control.csv: a CSV file containing information used when creating the figures.

6) Sample Comparisons.dta: Stata data set containing information on the sample.
 
