######################################################################################
### Script file to produce some preliminary models for the diffusion example in R
###
### Created: 3-13-17
### Modified: 6-7-18
###
######################################################################################

### set up working directory
setwd("~/Desktop/reproduction/application")

library(foreign)
library(sna)

###############################################################
### Generate second- and third-order matrices for 1994
###############################################################
d1994 <- read.dta("generate data/W/W1994.dta")
w1994 <- as.matrix(d1994)
w1994.2 <- neighborhood(w1994, 2)
w1994.3 <- neighborhood(w1994, 3)

write.dta(as.data.frame(w1994), file="generate data/W/R/W1994.dta")
write.dta(as.data.frame(w1994.2), file="generate data/W/R/W1994_o2.dta")
write.dta(as.data.frame(w1994.3), file="generate data/W/R/W1994_o3.dta")

