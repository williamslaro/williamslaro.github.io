# Reproduction Files Readme

### Guy D. Whitten | Laron K. Williams | Cameron Wimpy

#### 6-8-2018

This document outlines the steps needed for the reproduction files associated with Whitten, Williams, and Wimpy PSRM Spatial Interpretation Paper. 

## Software and programs

These files require both `Stata` and `R`. In `Stata` you will need the `spatwmat` package found [here](http://www.stata.com/stb/stb60). In `R`, you will need the `gridExtra`, `haven`, and `tidyverse` packages from CRAN. The script files `"application/application reproduction.do"` and `"examples/examples.do"` reproduce all tables, estimates, and matrices shown in the paper. The `R Markdown` file `figured.Rmd` . All needed datasets are provided and referenced in the script files. The script files are setup to run as-is on a user's desktop on Windows or Mac. If a user places the folder elsewhere we recommend to change directories as needed.

## Reproduction

Although you can run all files in an interactive fashion, we recommend running each file as a batch and then reading the associated log (`.smcl`) and `.html` files. For convenience, we provide PDFs of the `Stata` log files in the event a user does not have that program. 

## Data 

The dataset `"application/diffusion.dta"` is our primary dataset for the diffusion examples in the text and figures. These data are used in various levels of aggregation and shape in order to make the figures, and each figure includes its own dataset in the `"figures`" folder. These data can be used as provided or re-generated using the `"application/application reproduction.do"` file. Note that we set a seed for starting points that will need to be maintained in order to reproduce the datasets as we provide them. 

The folder `"application/generate data"` includes several ancillary files needed to generate and use our higher-order weighting matrices and country codes for merging. These data are referenced as needed in the `"application/application reproduction.do"` file. The file `"application/generate data/Generate Higher-Order Weights.R`" demonstrates how we generated the higher-order matrices and requires the `sna` package from CRAN. Note that while we include this file for transparency, we do not require it in order to replicate the examples in the paper. 

## Figures 

The figures are all created in using the `"figures/figures.Rmd"` file in the `R Markdown` implementation of `R Studio`. For convenience, the `rstudioapi` package is used to remove the need for any working directory issues across platforms but the remaining code should also run in base `R` or the `R` console of your choice so long as it remains intact. Each of the figures imports a dataset produced in the diffusion application discussed above and in the paper. The code will not run as is unless all required packages (noted above) and `ggplot2` themes are generated first. The file produces both stand-alone figures as well as the associated `.html` output file.