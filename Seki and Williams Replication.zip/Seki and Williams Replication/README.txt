This zipped folder contains all the files necessary to replicate all the empirical results and figures contained in the Seki and Williams "Updating the Party Government Data Set", Electoral Studies.

The folder contains the following files:

1) The "WKB Survey" files show how to produce the WKB Survey marginals presented in Table 2.  There is a Stata data set ("WKB Survey.dta"), do file ("WKB Survey.do"), and log file ("Survey Descriptives.smcl").

2) "Seki and Williams--Figures Replication.R" gives the code to reproduce the three figures in R.  You will also need all the data sets (called "duration*", "first*", "ministers*" and "rep*").

Please feel free to contact me if you have any questions: williamslaro@missouri.edu