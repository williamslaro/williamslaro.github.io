#######################################################################################
### R file to replicate the figures presented in Seki and Williams' Electoral Studies piece.
###
### Created: 10-25-13
### Modified: 
###
#######################################################################################

library(foreign)
library(ggplot2)
library(lattice)
library(fields)

#######################################################################################
### Set up the working directory and load the data 
#######################################################################################

# Set up the working directory!
#setwd("C:")

# Load the various data sets
duration = read.dta("duration.dta", convert.underscore=TRUE) 
duration3 = read.dta("duration3.dta", convert.underscore=TRUE)
duration4 = read.dta("duration4.dta", convert.underscore=TRUE)
duration5 = read.dta("duration5.dta", convert.underscore=TRUE)
first = read.dta("first.dta", convert.underscore=TRUE)
first3 = read.dta("first3.dta", convert.underscore=TRUE)
first4 = read.dta("first4.dta", convert.underscore=TRUE)
first5 = read.dta("first5.dta", convert.underscore=TRUE)
rep = read.dta("rep.dta", convert.underscore=TRUE)
rep3 = read.dta("rep3.dta", convert.underscore=TRUE)
rep4 = read.dta("rep4.dta", convert.underscore=TRUE)
rep5 = read.dta("rep5.dta", convert.underscore=TRUE)
ministers = read.dta("ministers.dta", convert.underscore=TRUE)
ministers3 = read.dta("ministers3.dta", convert.underscore=TRUE)
ministers4 = read.dta("ministers4.dta", convert.underscore=TRUE)
ministers5 = read.dta("ministers5.dta", convert.underscore=TRUE)



#######################################################################################
### Previous figures, side by side
#######################################################################################
g <- ggplot(duration) + aes(strccode, duration) + geom_boxplot() + ylab("Duration (in days)") + xlab("Country") + coord_flip()
g <- g + scale_x_discrete(limits=c("France IV","Slovakia","Lithuania","Finland II","Israel","Belgium","Finland I","Latvia","Japan","Italy","Poland","Romania","France V","Czech Republic","Slovenia","Portugal","Australia","Sweden I","Hungary","Estonia","Denmark","Norway","Iceland","Greece","Sweden II","Ireland","Germany","New Zealand","Canada","Austria","Bulgaria","Great Britain","Netherlands","Spain","Luxembourg","Malta"))
g <- g + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
g

p <- ggplot(duration) + aes(strccode, duration)
p <- p + geom_boxplot(data = duration3, fill = "grey60") #+ annotate("text", label = "CIEP=3", x = 1, y = 1750, size = 3)
p <- p + geom_boxplot(data = duration4, fill = "grey80") #+ annotate("text", label = "CIEP=4", x = 6, y = 1750, size = 3)
p <- p + geom_boxplot(data = duration5, fill = "grey95")  + ylab("Duration (in days)") + xlab("Country") + coord_flip() #+ annotate("text", label = "CIEP=5", x = 29, y = 1750, size = 3)
p <- p + scale_x_discrete(limits=c("Finland I","Australia","Sweden II","New Zealand","Slovakia","Lithuania","Finland II","Israel","Belgium","Latvia","Japan","Poland","Romania","Czech Republic","Slovenia","Portugal","Hungary","Estonia","Denmark","Norway","Iceland","Greece","Sweden I","Germany","Austria","Bulgaria","Netherlands","Spain","France IV","Italy","France V","Ireland","Canada","Great Britain","Luxembourg","Malta")) + labs(x = NULL)
p <- p + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
p

pdf(file = "dur.pdf", width = 6.5, height = 6.5)
grid.newpage()
pushViewport(viewport(layout = grid.layout(1,2)))

vplayout <- function(x, y)
	viewport(layout.pos.row = x, layout.pos.col = y)
print(g, vp = vplayout(1, 1))
print(p, vp = vplayout(1, 2))

dev.off()


#######################################################################################
### Duration of First Post-Election Governments as a Percentage of CIEP Remaining
#######################################################################################
pdf(file = "first_perc.pdf", width = 6.5, height = 6.5)
fp <- ggplot(first) + aes(strccode, duration.ciep) + geom_boxplot() + ylab("Government Duration as a % of CIEP Remaining") + xlab("Country") + coord_flip()
fp <- fp + scale_x_discrete(limits=c("France IV","Italy","Latvia","Romania","Israel","Lithuania","Poland","Japan","Belgium","France V","Finland II","Denmark","Estonia","Czech Republic","Ireland","Finland I","Portugal","Norway","Greece","Canada","Slovenia","Great Britain","Iceland","Austria","Germany","Sweden I","Netherlands","Australia","Luxembourg","Spain","Malta","Hungary","Slovakia","New Zealand","Sweden II","Bulgaria"))
fp

dev.off()

#######################################################################################
### Government duration as a % of CIEP remaining by country; divided into length of CIEP
### First Post-Election Government
#######################################################################################
pdf(file = "first_perc_ciep.pdf", width = 6.5, height = 6.5)
fpc <- ggplot(first) + aes(strccode, duration.ciep)
fpc <- fpc + geom_boxplot(data = first3, fill = "grey60") + annotate("text", label = "CIEP=3", x = 1, y = 110, size = 6)
fpc <- fpc + geom_boxplot(data = first4, fill = "grey80") + annotate("text", label = "CIEP=4", x = 7, y = 110, size = 6)
fpc <- fpc + geom_boxplot(data = first5, fill = "grey95") + annotate("text", label = "CIEP=5", x = 31, y = 110, size = 6) + ylab("Government Duration as a % of CIEP Remaining") + xlab("Country") + coord_flip()
fpc <- fpc + scale_x_discrete(limits=c("Finland I","Sweden I","Australia","New Zealand","Latvia","Romania","Israel","Lithuania","Poland","Japan","Belgium","Finland II","Denmark","Estonia","Czech Republic","Portugal","Norway","Greece","Slovenia","Iceland","Austria","Germany","Netherlands","Spain","Hungary","Slovakia","Sweden II","Bulgaria","France IV","Italy","France V","Ireland","Canada","Great Britain","Luxembourg","Malta"))
fpc
dev.off()


#######################################################################################
### Duration of Replacement Governments as a Percentage of CIEP Remaining
#######################################################################################
pdf(file = "rep_perc.pdf", width = 6.5, height = 6.5)
rp <- ggplot(rep) + aes(strccode, duration.ciep) + geom_boxplot() + ylab("Government Duration as a % of CIEP Remaining") + xlab("Country") + coord_flip()
rp <- rp + scale_x_discrete(limits=c("France IV","Slovakia","Portugal","Poland","Belgium","Israel","Canada","Italy","France V","Japan","Finland I","Bulgaria","Latvia","Sweden II","Australia","Denmark","Romania","Lithuania","Finland II","Ireland","Czech Republic","Great Britain","Netherlands","Greece","Austria","Malta","Iceland","Sweden I","Luxembourg","Spain","Germany","Hungary","Slovenia","Estonia","Norway","New Zealand"))
rp

dev.off()

#######################################################################################
### Government duration as a % of CIEP remaining by country; divided into length of CIEP
### Replacement Government
#######################################################################################
pdf(file = "rep_perc_ciep.pdf", width = 6.5, height = 6.5)
rpc <- ggplot(rep) + aes(strccode, duration.ciep)
rpc <- rpc + geom_boxplot(data = rep3, fill = "grey60") + annotate("text", label = "CIEP=3", x = 1, y = 107, size = 4)
rpc <- rpc + geom_boxplot(data = rep4, fill = "grey80") + annotate("text", label = "CIEP=4", x = 7, y = 107, size = 4)
rpc <- rpc + geom_boxplot(data = rep5, fill = "grey95") + annotate("text", label = "CIEP=5", x = 31, y = 107, size = 4) + ylab("Government Duration as a % of CIEP Remaining") + xlab("Country") + coord_flip()
rpc <- rpc + scale_x_discrete(limits=c("Finland I","Australia","Sweden I","New Zealand","Slovakia","Portugal","Poland","Belgium","Israel","Japan","Bulgaria","Latvia","Sweden II","Denmark","Romania","Lithuania","Finland II","Czech Republic","Netherlands","Greece","Austria","Iceland","Spain","Germany","Hungary","Slovenia","Estonia","Norway","France IV","Canada","Italy","France V","Ireland","Great Britain","Malta","Luxembourg"))
rpc
dev.off()

#######################################################################################
### % CIEP Remaining: first versus replacement governments
#######################################################################################

fp <- ggplot(first) + aes(strccode, duration.ciep) + geom_boxplot() + ylab("% of CIEP Remaining") + xlab("Country") + coord_flip()
fp <- fp + scale_x_discrete(limits=c("France IV","Italy","Latvia","Romania","Israel","Lithuania","Poland","Japan","Belgium","France V","Finland II","Denmark","Estonia","Czech Republic","Ireland","Finland I","Portugal","Norway","Greece","Canada","Slovenia","Great Britain","Iceland","Austria","Germany","Sweden I","Netherlands","Australia","Luxembourg","Spain","Malta","Hungary","Slovakia","New Zealand","Sweden II","Bulgaria"))
fp

rp <- ggplot(rep) + aes(strccode, duration.ciep) + geom_boxplot() + ylab("% of CIEP Remaining") + xlab("Country") + coord_flip()
rp <- rp + scale_x_discrete(limits=c("France IV","Slovakia","Portugal","Poland","Belgium","Israel","Canada","Italy","France V","Japan","Finland I","Bulgaria","Latvia","Sweden II","Australia","Denmark","Romania","Lithuania","Finland II","Ireland","Czech Republic","Great Britain","Netherlands","Greece","Austria","Malta","Iceland","Sweden I","Luxembourg","Spain","Germany","Hungary","Slovenia","Estonia","Norway","New Zealand")) + labs(x = NULL)
rp

pdf(file = "perc.pdf", width = 6.5, height = 6.5)
grid.newpage()
pushViewport(viewport(layout = grid.layout(1,2)))

vplayout <- function(x, y)
	viewport(layout.pos.row = x, layout.pos.col = y)
print(fp, vp = vplayout(1, 1))
print(rp, vp = vplayout(1, 2))

dev.off()

#######################################################################################
### % CIEP Remaining: first versus replacement governments: divided into CIEP lengths
#######################################################################################

fpc <- ggplot(first) + aes(strccode, duration.ciep)
fpc <- fpc + geom_boxplot(data = first3, fill = "grey60") # + annotate("text", label = "CIEP=3", x = 1, y = 110, size = 6)
fpc <- fpc + geom_boxplot(data = first4, fill = "grey80") # + annotate("text", label = "CIEP=4", x = 7, y = 110, size = 6)
fpc <- fpc + geom_boxplot(data = first5, fill = "grey95") + ylab("% of CIEP Remaining") + xlab("Country") + coord_flip() #+ annotate("text", label = "CIEP=5", x = 31, y = 110, size = 6)
fpc <- fpc + opts(plot.title = theme_text(family = "serif", face = "bold", size = 16, hjust = 0.5), title = "First Governments") + scale_x_discrete(limits=c("Finland I","Sweden I","Australia","New Zealand","Latvia","Romania","Israel","Lithuania","Poland","Japan","Belgium","Finland II","Denmark","Estonia","Czech Republic","Portugal","Norway","Greece","Slovenia","Iceland","Austria","Germany","Netherlands","Spain","Hungary","Slovakia","Sweden II","Bulgaria","France IV","Italy","France V","Ireland","Canada","Great Britain","Luxembourg","Malta"))
fpc <- fpc + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
fpc

rpc <- ggplot(rep) + aes(strccode, duration.ciep)
rpc <- rpc + geom_boxplot(data = rep3, fill = "grey60") #+ annotate("text", label = "CIEP=3", x = 1, y = 107, size = 4)
rpc <- rpc + geom_boxplot(data = rep4, fill = "grey80") #+ annotate("text", label = "CIEP=4", x = 7, y = 107, size = 4)
rpc <- rpc + geom_boxplot(data = rep5, fill = "grey95")  + ylab("% of CIEP Remaining") + xlab("Country") + coord_flip() #+ annotate("text", label = "CIEP=5", x = 31, y = 107, size = 4) + ylab("% of CIEP Remaining") + xlab("Country") + coord_flip()
rpc <- rpc + opts(plot.title = theme_text(family = "serif", face = "bold", size = 16, hjust = 0.5), title = "Replacement Governments") + scale_x_discrete(limits=c("Finland I","Australia","Sweden I","New Zealand","Slovakia","Portugal","Poland","Belgium","Israel","Japan","Bulgaria","Latvia","Sweden II","Denmark","Romania","Lithuania","Finland II","Czech Republic","Netherlands","Greece","Austria","Iceland","Spain","Germany","Hungary","Slovenia","Estonia","Norway","France IV","Canada","Italy","France V","Ireland","Great Britain","Malta","Luxembourg")) + labs(x = NULL)
rpc <- rpc + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
rpc

pdf(file = "perc_ciep.pdf", width = 6.5, height = 6.5)
grid.newpage()
pushViewport(viewport(layout = grid.layout(1,2)))

vplayout <- function(x, y)
	viewport(layout.pos.row = x, layout.pos.col = y)
print(fpc, vp = vplayout(1, 1))
print(rpc, vp = vplayout(1, 2))

dev.off()


#######################################################################################
### Ministers' cumulative duration by country
#######################################################################################
pdf(file = "min_dur.pdf", width = 6.5, height = 6.5)
m <- ggplot(ministers) + aes(strccode, cum.duration) + geom_boxplot() + ylab("Cumulative Duration of Ministers (in days)") + xlab("Country") + coord_flip()
m <- m + scale_x_discrete(limits=c("Japan","Romania","Poland","France V","Lithuania","Latvia","Italy","Bulgaria","Czech Republic","Hungary","Slovakia","Sweden I","Estonia","Slovenia","Greece","Spain","Belgium","Portugal","Norway","Finland II","Australia","Austria","Netherlands","Sweden II","Israel","Canada","Great Britain","Germany","Denmark","Iceland","New Zealand","Ireland","Malta","Luxembourg"))
m
dev.off()

#######################################################################################
### Minister's cumulative duration by country; divided into length of CIEP
#######################################################################################
pdf(file = "min_ciep.pdf", width = 6.5, height = 6.5)
mc <- ggplot(ministers) + aes(strccode, cum.duration)
mc <- mc + geom_boxplot(data = ministers3, fill = "grey60") + annotate("text", label = "CIEP=3", x = 1, y = 6000, size = 4)
mc <- mc + geom_boxplot(data = ministers4, fill = "grey80") + annotate("text", label = "CIEP=4", x = 4, y = 6000, size = 4)
mc <- mc + geom_boxplot(data = ministers5, fill = "grey95") + annotate("text", label = "CIEP=5", x = 28, y = 6000, size = 4) + ylab("Cumulative Duration of Ministers (in days)") + xlab("Country") + coord_flip()
mc <- mc + scale_x_discrete(limits=c("Sweden I","Australia","New Zealand","Japan","Romania","Poland","Lithuania","Latvia","Bulgaria","Czech Republic","Hungary","Slovakia","Estonia","Slovenia","Greece","Spain","Belgium","Portugal","Norway","Finland II","Austria","Netherlands","Sweden II","Israel","Germany","Denmark","Iceland","France V","Italy","Canada","Great Britain","Ireland","Malta","Luxembourg"))
mc
dev.off()

#######################################################################################
### Ministers' Cumulative Duration: 1 x 2 figure.
#######################################################################################
m <- ggplot(ministers) + aes(strccode, cum.duration) + geom_boxplot() + ylab("Cumulative Duration of Ministers (in days)") + xlab("Country") + coord_flip() 
m <- m + scale_y_continuous(breaks=c(0,3000,6000)) + scale_x_discrete(limits=c("Japan","Romania","Poland","France V","Lithuania","Latvia","Italy","Bulgaria","Czech Republic","Hungary","Slovakia","Sweden I","Estonia","Slovenia","Greece","Spain","Belgium","Portugal","Norway","Finland II","Australia","Austria","Netherlands","Sweden II","Israel","Canada","Great Britain","Germany","Denmark","Iceland","New Zealand","Ireland","Malta","Luxembourg")) 
m <- m + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
m

mc <- ggplot(ministers) + aes(strccode, cum.duration)
mc <- mc + geom_boxplot(data = ministers3, fill = "grey60") #+ annotate("text", label = "CIEP=3", x = 1, y = 6300, size = 4)
mc <- mc + geom_boxplot(data = ministers4, fill = "grey80") #+ annotate("text", label = "CIEP=4", x = 4, y = 6300, size = 4)
mc <- mc + geom_boxplot(data = ministers5, fill = "grey95")  + ylab("Cumulative Duration of Ministers (in days)") + xlab("Country") + coord_flip() #+ annotate("text", label = "CIEP=5", x = 28, y = 6300, size = 4)
mc <- mc + scale_y_continuous(breaks=c(0,3000,6000)) + scale_x_discrete(limits=c("Sweden I","Australia","New Zealand","Japan","Romania","Poland","Lithuania","Latvia","Bulgaria","Czech Republic","Hungary","Slovakia","Estonia","Slovenia","Greece","Spain","Belgium","Portugal","Norway","Finland II","Austria","Netherlands","Sweden II","Israel","Germany","Denmark","Iceland","France V","Italy","Canada","Great Britain","Ireland","Malta","Luxembourg")) + labs(x = NULL)
mc <- mc + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
mc

pdf(file = "min.pdf", width = 6.5, height = 6.5)
grid.newpage()
pushViewport(viewport(layout = grid.layout(1,2)))

vplayout <- function(x, y)
	viewport(layout.pos.row = x, layout.pos.col = y)
print(m, vp = vplayout(1, 1))
print(mc, vp = vplayout(1, 2))

dev.off()












#######################################################################################
### old code
#######################################################################################

## ggplot2
ggplot(duration3, aes(strccode, duration)) + geom_boxplot() + ylab("Duration (in days)")
ggplot(duration4, aes(strccode, duration)) + geom_boxplot() + ylab("Duration (in days)")
ggplot(duration5, aes(strccode, duration)) + geom_boxplot() + ylab("Duration (in days)")

qplot(strccode, duration, data = duration3, facets = strccode ~ ., geom = "boxplot")

# Good figure!
qplot(strccode, duration, data = duration, facets = ciep.year ~ ., geom = "boxplot")

qplot(strccode, duration, data = duration, facets = ciep.year ~ ., geom = "boxplot")

# Horizontal!
p <- ggplot(duration, aes(strccode, duration))
p + geom_boxplot() + coord_flip()

# Horizontal, as qplot
qplot(strccode, duration, data = duration, geom = "boxplot") + coord_flip()

# Horizontal, with different colors
p <- ggplot(duration, aes(strccode, duration))
p + geom_boxplot(aes(fill = factor(ciep.year))) + coord_flip()

#p <- ggplot(duration, aes(strccode, duration))
p <- ggplot(duration)
p <- p + aes(strccode, duration)
p <- p + layer(geom = "boxplot", data = duration3) + coord_flip()
p <- p + layer(geom = "boxplot", data = duration4) + coord_flip()
p <- p + layer(geom = "boxplot", data = duration5) + coord_flip()
p

# Best looking figure: different shades for ciep_year
p <- ggplot(duration) + aes(strccode, duration)
p <- p + geom_boxplot(data = duration3, fill = "grey60")
p <- p + geom_boxplot(data = duration4, fill = "grey80")
p <- p + geom_boxplot(data = duration5, fill = "grey95") + ylab("Duration (in days)") + xlab("Country") + coord_flip()
p

# Different shades for ciep_year, horizontal lines separating systems
p <- ggplot(duration) + aes(strccode, duration)
p <- p + geom_boxplot(data = duration3, fill = "grey60") + geom_vline(xintercept=c(4.75,28.5))
p <- p + geom_boxplot(data = duration4, fill = "grey80") 
p <- p + geom_boxplot(data = duration5, fill = "grey95") + ylab("Duration (in days)") + xlab("Country") + coord_flip()
p

# Best looking figure: different shades for ciep_year; labels for CIEP systems
p <- ggplot(duration) + aes(strccode, duration)
p <- p + geom_boxplot(data = duration3, fill = "grey60")
p <- p + geom_boxplot(data = duration4, fill = "grey80")
p <- p + geom_boxplot(data = duration5, fill = "grey95") + ylab("Duration (in days)") + xlab("Country") + coord_flip()
p <- p + annotate("text", label = "CIEP=3", x = 4, y = 1700, size = 6)
p <- p + annotate("text", label = "CIEP=4", x = 28, y = 1700, size = 6)
p <- p + annotate("text", label = "CIEP=5", x = 37.5, y = 1700, size = 6)
p

# Best looking figure: different colors for ciep_year
p <- ggplot(duration) + aes(strccode, duration, fill = ciep.year)
p <- p + geom_boxplot(data = duration3)
p <- p + geom_boxplot(data = duration4)
p <- p + geom_boxplot(data = duration5) + ylab("Duration (in days)") + xlab("Country") + coord_flip()
p


# figure out how to sort
# add shading for the different catgories?


p <- p + layer(geom = "boxplot", data = duration3) + coord_flip()
p <- p + layer(geom = "boxplot", data = duration4) + coord_flip()
p <- p + layer(geom = "boxplot", data = duration5) + coord_flip()
p




# doesn't work so hot
qplot(strccode, duration, data = duration, geom = "boxplot") + xlab("Country") + facet_grid(ciep.year ~ ., scales = "fixed") + coord_flip()


p <- ggplot(duration, aes(strccode, duration)) 
p + geom_boxplot()

p <- ggplot(duration, aes(strccode, duration))
p <- p + layer(geom = "boxplot", data = duration3) 
p
p <- p + layer(geom = "boxplot", data = duration4) 
p
p <- p + layer(geom = "boxplot", data = duration5)
p


















boxplot(duration ~ countryid, data = duration, xlab = "Government Duration", ylab = "Country", horizontal = TRUE)

## Lattice
bwplot(duration ~ ccode, data = duration, xlab="Country", ylab="Duration (in days)")










### using bplot (doesn't quite work)
A = read.dta("Australia.dta", convert.underscore=TRUE) 
C = read.dta("Canada.dta", convert.underscore=TRUE) 

bplot(A$duration, by=A$countryid, horizontal=TRUE)
bplot(C$duration, by=C$countryid, horizontal=TRUE, add=TRUE)

bplot(A$duration, pos=2, horizontal=TRUE)
bplot(C$duration, pos=33, horizontal=TRUE, add=TRUE)



d <- matrix(NA,35,ncol=2)
d[1:35,1] <- A$duration
d[1:26,2] <- C$duration

bplot(d, pos=c(2,3),horizontal=TRUE)




xlim <- c(0,2000)    # x-axis range
ylim <- c(0.5,36.5)  # y-axis range
lwd=2
cexp=0.8

#xla <- c("-50","0","50")
#yla <- c("0", ".02", ".04",".06")
#ylabat <- c("", "", "")

xrng <- c(xlim[1],xlim[2],xlim[2],xlim[1])
yrng <- c(ylim[1],ylim[2],ylim[2],ylim[1])

#par(fig=c(0,1,0.1,1),mar=c(.25,7,.5,1))
#plot(duration$duration, duration$countryid, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")

par(fig=c(0,1,0.7,1),mar=c(.25,7,.5,1))
plot(seq(1, 4, by=1), seq(1, 4, by=1), xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration ~ duration$countryid, horizontal=TRUE, add= TRUE, subset = duration$ciep.year == 3, axes="F")

par(fig=c(0,1,0.4,.7),mar=c(.25,7,.5,1), new=TRUE)
plot(seq(5, 28, by=1), seq(5, 28, by=1), xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration ~ duration$countryid, horizontal=TRUE, add= TRUE, subset = duration$ciep.year == 4, axes="F")

par(fig=c(0,1,0.1,.4),mar=c(.25,7,.5,1), new=TRUE)
plot(seq(29, 36, by=1), seq(29, 36, by=1), xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration ~ duration$countryid, horizontal=TRUE, add= TRUE, subset = duration$ciep.year == 5, axes="F")


bplot(duration$duration, by=duration$countryid, horizontal=TRUE)





### pretty good set of code
par(fig=c(0,1,0.7,1),mar=c(.25,7,.5,1))
plot(duration$duration, duration$countryid, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration ~ duration$countryid, horizontal=TRUE, add= TRUE, subset = duration$ciep.year == 3, axes="F")

par(fig=c(0,1,0.4,.7),mar=c(.25,7,.5,1), new=TRUE)
plot(duration$duration, duration$countryid, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration ~ duration$countryid, horizontal=TRUE, add= TRUE, subset = duration$ciep.year == 4, axes="F")

par(fig=c(0,1,0.1,.4),mar=c(.25,7,.5,1), new=TRUE)
plot(duration$duration, duration$countryid, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration ~ duration$countryid, horizontal=TRUE, add= TRUE, subset = duration$ciep.year == 5, axes="F")















par(fig=c(0,1,0.9,1),mar=c(.25,7,.5,1))
plot(duration$duration, duration$countryid, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration, horizontal=TRUE, add= TRUE, subset = duration$countryid == 35, axes="F")

par(fig=c(0,1,0.8,.9),mar=c(.25,7,.5,1), new=TRUE)
plot(duration$duration, duration$countryid, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration, horizontal=TRUE, add= TRUE, subset = duration$countryid == 30, axes="F")

par(fig=c(0,1,0.7,.8),mar=c(.25,7,.5,1), new=TRUE)
plot(duration$duration, duration$countryid, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
boxplot(duration$duration, horizontal=TRUE, add= TRUE, subset = duration$countryid == 1, axes="F")
#boxplot(duration$duration, horizontal=TRUE, subset = duration$countryid == 1, axes="F")


for(i in seq(1, 36, by=1)) {
#	boxplot(duration$duration ~ duration$countryid, horizontal = TRUE, add = TRUE, subset = duration$countryid == i, axes="F")
	
#	plot(0, i+1, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")

	boxplot(duration$duration, horizontal=TRUE, add= TRUE, subset = duration$countryid == i, axes="F")

}


boxplot(duration$duration ~ duration$countryid, horizontal = TRUE, add = TRUE, subset = duration$countryid == 1, axes="F")
















