README for: Look Over There. Where? A Compositional Approach to the Modeling of Public Opinion on the Most Important Problem
Authors: Steven Jokinsky, Christine Lipsmeyer, Andrew Philips, Laron Williams, Guy Whitten
Last updated: 3/4/24
Files:

1. SSQ-replication-PID
	-description: replicates party ID results
	-input files needed: ssq-replicationdata-pid.dta, dynsimpieladderplotldv.ado, multidynsimpieldv.ado
	-output: Figure 2, Figure 3, Figure 4, Figure 7, Figure 8, SI Figure A4, SI Table A4, SI Table A.1
	
2. SSQ-replication-gender
	-description: replicates gender results
	-input files needed: ssq-replicationdata-gender.dta, dynsimpieladderplotldv.ado, multidynsimpieldv.ado
	-output: Figure 5, Figure 9, Figure 10, SI Figure A5, SI Table A2, SI Table A5
	
3. SSQ-replication-income
	-description: replicates income results
	-input files needed: ssq-replicationdata-income, dynsimpieladderplotldv.ado, multidynsimpieldv.ado
	-output: Figure 6, Figure 11, Figure 12, SI Figure A6, SI Table A3, SI Table A6
	
4. multidynsimpieldv.ado: program used to dynamically simulate the partisan, gender and income differences plots

5. dynsimplieladderplotldv.ado: program used to dynamically simulate the effects of shocks of independent variables

6. ssq-replicationdata-pid.dta: dataset needed for SSQ-replication-PID

7. ssq-replicationdata-gender.dta: dataset needed for SSQ-replication-gender

8. ssq-replicationdata-income.dta: dataset needed for SSQ-replication-income

9. Issue Importance - Figures.R
	-description: produces several figures related to data coverage and missingness
	-input files needed: Issue Importance.dta, II.dta
	-output: Figure 1, SI Figure A1, SI Figure A2, SI Figure A3
	
10. Issue Importance.dta: Dataset needed for Issue Importance - Figures.R

11. II.dta: Dataset needed for Issue Importance - Figures.R