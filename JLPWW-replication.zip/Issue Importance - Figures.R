################################################################################
### Replication file "Issue Importance - Figures.R"
### Look Over There. Where? A Compositional Approach to the Modeling of Public Opinion on the Most Important Problem
### Authors: Steven Jokinsky, Christine Lipsmeyer, Andrew Philips, Laron Williams, Guy Whitten
###
### Last updated: 3/4/24
###
### NOTE: thanks to Thiago Silva for his code for heat maps
################################################################################

# Load libraries
#install.packages("tidyverse")
library(tidyverse)
library(foreign)

# directory
setwd("/Users/aqpimac/Dropbox/Lipsmeyer_Philips_Whitten_Williams/SSQ Submission 2023/Final Version/Replication")

#######################################################################################
### Figure 1: Issue importance over time (1967-2015)
#######################################################################################

agg = read.dta("Issue Importance.dta", convert.underscore=TRUE)

#pdf(file="Manuscript/figures/mip.pdf", family="Times")
r <- ggplot(data=subset(agg, topic == "Economic Issues" | topic == "International Affairs" | topic == "Social Welfare" | topic == "Culture" | topic == "Crime"))
r <- r + geom_smooth(aes(group = topic, fill = topic, linetype = topic, x=tsm, y=cap), size = 1.25) 
r <- r + ylab("Most Important Problem (%)") + xlab("")
r <- r + scale_y_continuous(limits=c(-5, 60))
r <- r + scale_x_continuous(breaks=c(120, 240, 360, 480, 600), labels=c("1970", "1980", "1990", "2000", "2010"))
r <- r + theme(legend.title=element_blank(), legend.position="bottom", panel.background = element_blank(), axis.line = element_line(colour = "black"), panel.grid.minor = element_line(color = "lightgrey"))
r <- r + scale_fill_grey()
r <- r + scale_linetype_manual(values=c("twodash", "dotdash", "solid", "longdash", "dotted"))
r
#dev.off()

#######################################################################################
### SI Figure A.1: Survey availability (1967-2015)
#######################################################################################

data <- read.dta("II.dta")

### Remove those months if numsurveys == 0
data.s <- subset(data, numsurveys != 0)

### Availability of surveys
#pdf(file = "Appendix/figures/miss.pdf")
ggplot(data.s, aes(x = month, y = year, fill = numsurveys)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "#FFE6E6", high = "#FF0000", breaks = seq(0, 7, 2), labels = seq(0, 7, 2)) +
  theme_bw() +
  xlab("Month") +
  ylab("Year") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
        axis.title.x = element_text(margin = margin(t = 10)),
        axis.title.y = element_text(margin = margin(r = 10)),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(label = ifelse(numsurveys > 0, numsurveys, "")),
            color = "black", size = 3) +
  coord_equal() +
  scale_y_reverse(limits = c(2016, 1966), expand=c(0,0), breaks = seq(1967, 2015, 1)) +
  scale_x_continuous(limits = c(0, 13), expand = c(0, 0), breaks = seq(1, 12, 1), labels = paste0(c('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'))) +   
 labs(fill = "Surveys")
#dev.off()


#######################################################################################
### SI Figure A.2: Occurrence of international crises (1967-2013)
#######################################################################################
### Remove those months with no crises
data.c <- subset(data, icb_total != 0)

#pdf(file = "Appendix/figures/icb.pdf")
ggplot(data.c, aes(x = month, y = year, fill = icb_total)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "#FFE6E6", high = "#FF0000", breaks = seq(0, 7, 2), labels = seq(0, 7, 2)) +
  theme_bw() +
  xlab("Month") +
  ylab("Year") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
        axis.title.x = element_text(margin = margin(t = 10)),
        axis.title.y = element_text(margin = margin(r = 10)),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(label = ifelse(icb_total > 0, icb_total, "")),
            color = "black", size = 3) +
  coord_equal() +
  scale_y_reverse(limits = c(2014, 1966), expand=c(0,0), breaks = seq(1967, 2013, 1)) +
  scale_x_continuous(limits = c(0, 13), expand = c(0, 0), breaks = seq(1, 12, 1), labels = paste0(c('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'))) +   
  labs(fill = "Crises (ICB)")
#dev.off()


#######################################################################################
### SI Figure A.3: Occurrence of serious international crises (1967-2013)
#######################################################################################

### Remove those months with no crises
data.c34 <- subset(data, icb34_total != 0)

#pdf(file = "Appendix/figures/icb34.pdf")
ggplot(data.c34, aes(x = month, y = year, fill = icb34_total)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "#FFE6E6", high = "#FF0000", breaks = seq(0, 7, 2), labels = seq(0, 7, 2)) +
  theme_bw() +
  xlab("Month") +
  ylab("Year") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
        axis.title.x = element_text(margin = margin(t = 10)),
        axis.title.y = element_text(margin = margin(r = 10)),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(label = ifelse(icb34_total > 0, icb34_total, "")),
            color = "black", size = 3) +
  coord_equal() +
  scale_y_reverse(limits = c(2014, 1966), expand=c(0,0), breaks = seq(1967, 2013, 1)) +
  scale_x_continuous(limits = c(0, 13), expand = c(0, 0), breaks = seq(1, 12, 1), labels = paste0(c('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'))) +   
  labs(fill = "Crises (ICB Levels 3 and 4)")
#dev.off()
