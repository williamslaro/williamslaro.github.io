##=============================================================================#
## Opportunistic opposition parties
## Based on Daina Chiba's code
## This file has the code to reproduce the figures from the JPR manuscript.
## Created : 9-22-11
## Modified: 8-5-13
##=============================================================================#

# Establish the working directory!
#setwd("")

##==================================================#
## Predicted probability of of a NCM following international conflict across opposition party ideology
##==================================================#
b <- read.csv("prm2.csv", sep=",", header=TRUE)
b

mat <- matrix(NA,13,ncol=4)
colnames(mat) <- c("pr","lower","upper","CMP")
mat[,1] <- b[,3]
mat[,2] <- b[,1]
mat[,3] <- b[,2]
mat[,4] <- b[,4]

xlim <- c(-60,60)    # x-axis range
ylim <- c(0,.06)  # y-axis range
lwd=2
cexp=0.8
xla <- c("-50","0","50")
yla <- c("0", ".02", ".04",".06")
ylabat <- c("", "", "")
xrng <- c(xlim[1],xlim[2],xlim[2],xlim[1])
yrng <- c(ylim[1],ylim[2],ylim[2],ylim[1])

# Predicted probability of a NCM across opposition party ideology
par(fig=c(0,1,0.15,1),mar=c(.25,7,.5,1))
plot(mat[,1], mat[,4], xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
lines(mat[,4], mat[,1], lty=1, lwd=lwd)
lines(mat[,4], mat[,2], lty=2, lwd=lwd)
lines(mat[,4], mat[,3], lty=2, lwd=lwd)
axis(1,cex.axis=cexp, mgp=c(3,.4,0), labels=xla,at=xla)
axis(2,labels=yla,at=yla,las=1,cex.axis=cexp)
mtext("Pr(NCM)", 2, line=2.5, las=1)
mtext("Opposition party partisanship", 1, line = 2.5, las=1)

# Legend
par(fig=c(0,1,0,.1), new=TRUE, mar=c(.25,7,0,1), new=TRUE)
plot(mat[,1],mat[,4],xlim=xlim,ylim=ylim,cex=cexp,type="n",axes=F,ann=F)
leg.txt <- c("Probability", "95% confidence interval")
lty.type <- c(1,2)
legend(-50, 0.04, leg.txt, lty=lty.type, cex=1, bty="n", ncol=2, lwd=lwd)
text(-50,.055,"Left")
text(50,.055,"Right")





##==================================================#
## Probability of a NCM across government partisanship for left and right opposition parties.
##==================================================#
b <- read.csv("prm3.csv", sep=",", header=TRUE)
b

mat <- matrix(NA,21,ncol=8)
colnames(mat) <- c("me_l","lower_l","upper_l","me_r","lower_r","upper_r","cmp_l","cmp_r")
mat[,1] <- b[,5]
mat[,2] <- b[,1]
mat[,3] <- b[,2]
mat[,4] <- b[,6]
mat[,5] <- b[,3]
mat[,6] <- b[,4]
mat[,7] <- b[,7]
mat[,8] <- b[,7] + 1

# Probability of a NCM across Government ideology for left and right opposition parties.
xlim <- c(-50,50)    # x-axis range
ylim <- c(0,.15)  # y-axis range
lwd=2
cexp=0.8
xla <- c("-50","0","50")
yla <- c("0", ".05", ".1", ".15")
ylabat <- c("", "", "")
xrng <- c(xlim[1],xlim[2],xlim[2],xlim[1])
yrng <- c(ylim[1],ylim[2],ylim[2],ylim[1])

par(fig=c(0,1,0.2,1),mar=c(.25,7,.5,1))
plot(mat[,7], mat[,1], xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
#lines(mat[,4], mat[,1], lty=1, lwd=lwd)
#lines(mat[,7], mat[,5], lty=2, lwd=lwd)
#lines(mat[,7], mat[,6], lty=2, lwd=lwd)
segments (mat[,7], mat[,2], mat[,7], mat[,3], lwd=1, lty=1, col="gray10")
segments (mat[,8], mat[,5], mat[,8], mat[,6], lwd=1, lty=2, col="gray10")
points(mat[,7], mat[,1], pch=19, cex=.5)
points(mat[,8], mat[,4], pch=19, cex=.5)

axis(1,cex.axis=cexp, mgp=c(3,.4,0), labels=xla,at=xla)
axis(2,labels=yla,at=yla,las=1,cex.axis=cexp)
mtext("Pr(NCM)", 2, line = 2.5, las=1)
mtext("Government partisanship", 1, line = 2.5, las=1)
  
# Legend
par(fig=c(0,1,0,.15),mar=c(.25,7,0,1), new=TRUE)
plot(mat[,7],mat[,1],xlim=xlim,ylim=ylim,cex=cexp,type="n",axes=F,ann=F)
leg.txt <- c("Left opposition", "Center/right opposition")
lty.type <- c(1,2)
legend(-45, .1, leg.txt, lty=lty.type, cex=1, bty="n", ncol=2, lwd=lwd)
text(-50,.145,"Left")
text(50,.145,"Right")

# Note
par(fig=c(0,1,0,.15), new=TRUE, mar=c(1.5,0,0,1))
mtext("Note: Figure depicts predicted probabilities (circles) and 95% confidence intervals (lines).",side=1,adj=0,cex=.7) 





