******************************************************************************
"Problem Importance across Time and Space: Updating the `Most Important Problem Dataset'"
T. Murat Yildrim and Laron K. Williams
Journal of Elections, Public Opinion & Parties
******************************************************************************

This folder contains all the files necessary to reproduce the two empirical applications.

******************************************************************************
Analysis of Quasi-Responses:
******************************************************************************

* "Multiple Responses - Generate Data.do": Stata do file that takes the original dataset (MIPD Release 2.0.dta, available upon request) and creates the data for the Multiple Responses analysis (Multiple Responses.dta).

* "Multiple Responses.dta": Stata data file

* "Multiple Responses - Analysis.do": Stata do file that does descriptive and inferential analysis on the prevalence of multiple quasi-responses

* "Multiple Responses - Analysis.smcl": Stata log file containing the descriptive and inferential analysis mentioned above

******************************************************************************
The Most Important Problem across States:
******************************************************************************

* "State Disproportionality - Generate Data.do": Stata do file that takes the original dataset (MIPD Release 2.0.dta, available upon request) and creates the data for the State-Level analysis (State Disproportionality.dta).

* "State Disproportionality.dta": Stata data file

* "State Disproportionality - Analysis.do": Stata do file that calculates the state-level measures and spatial measures (relies on the Wstates.dta file and US states shapefile); creates the Spatial Clustering.dta file

* "State Disproportionality - Analysis.smcl": Stata log file containing the state-level analysis

* Maps folder contains the shape files and weights matrix

