#######################################################################################
### R file to create some figures for the appendix in the Drolc, Gandrud and Williams PSJ project
###
### Created: 5-7-19
### Modified: 
###
#######################################################################################

library(foreign)
library(ggplot2)
library(lattice)
library(fields)
library(splines)
library(MASS)
library(gridExtra)

slx = read.dta("Figures/Data/SLX.dta", convert.underscore=TRUE)

#######################################################################################
### Figure 2: Mean squared error of theta_1 for Models that Include (Model 1) and Omit (Model 2) a Relevant Avenue of Diffusion (W_2X)
#######################################################################################

mse.data <- subset(slx, model != 3 & corr.13 == 0)

mse <- ggplot(data = mse.data, aes(x=corr.12, y=mse.theta.1.m)) + geom_line(aes(linetype = modelname))
mse <- mse + xlab(expression(paste("Network Correlation of ", W[1], " and ", W[2]))) + ylab(expression(paste("Mean Squared Error of  ", theta[1]))) + theme_minimal() + guides(linetype=guide_legend(title = NULL))
mse


#######################################################################################
### Figure 3: Median and 90% COnfidence Intervals of the Effects of \theta_1 Compared to the True Value (\theta_1=0.1) in Model 2
#######################################################################################

mn.data <- subset(slx, model == 2 & corr.13 == 0)

mn <- ggplot(data = mn.data, aes(x=corr.12)) + geom_errorbar(aes(ymin=lo.theta.1.m, ymax=hi.theta.1.m)) + geom_point(aes(y=median.theta.1.m))
mn <- mn + geom_hline(yintercept = 0.1, linetype = "dashed")
mn <- mn + xlab(expression(paste("Network Correlation of ", W[1], " and ", W[2]))) + ylab(expression(paste("Average Value of  ", theta[1]))) + theme_minimal() + guides(linetype=guide_legend(title = NULL))
mn

#######################################################################################
### Figure 4: False discovery rate for \theta_3 in a model that omits two true avenues of policy diffusion
#######################################################################################

fdr.data <- subset(slx, model == 3 & corr.12 == 0)

fdr <- ggplot(data = fdr.data, aes(x=corr.13, y=reject.theta.3.m)) + geom_line(aes(linetype = modelname))
fdr <- fdr + xlab(expression(paste("Network Correlation of ", W[1], " and ", W[3]))) + ylab(expression(paste("False Discovery Rate of  ", theta[3]))) + theme_minimal() + guides(linetype=guide_legend(title = NULL))
fdr <- fdr + theme(legend.position = "none")
fdr