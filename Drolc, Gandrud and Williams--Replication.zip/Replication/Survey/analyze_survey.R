#-------------------------------------------------------------------------------
# Taking Time (and Space) Seriously:
# How Scholars Falsely Infer Policy Diffusion from Model Misspecification

# Cody A. Drolc, Christopher Gandrud, and Laron K. Williams

# Reproduce survey results reported in Table 1

# Note: Simply citing prior literature that included a TLSL does not count
# as a theoretical justificiation
#-------------------------------------------------------------------------------

# Packages (install if needed)
pkgs <- c("dplyr", "rio")
lapply(pkgs, library, c = T)

# Set directory (Change as needed)
setwd("./Survey")
  
# Survey data
pds <- import("Policy_Diffusion_Survey.xlsx")

# Summarize Survey
pds.sum <- pds %>%
  summarize(Total = n(),
            TotalTLSL = sum(TLSL),
            ProportionUsingTLSL = mean(TLSL),
            Justification = mean(TheoryJust[TLSL == 1]),
            TemporalDependence = mean(TemporalDependenceID[TLSL == 1]),
            SpatialDiagnostics = mean(Moran[TLSL == 1]),
            SPLTE = mean(LR_Effects[TLSL == 1]),
            IncorrectNotation = mean(IncorrectNotation[TLSL == 1])) 
pds.sum

