#############################################################################
### Script file to produce a figure from Gilardi and Wasserfallen (2014) for the Drolc, Gandrud and Williams PSJ project.
###
### Created: 8-22-17
### Modified: 9-5-19
###
#############################################################################

library(maptools)
library(ggplot2)
library(sp)
library(foreign)
library(grid)
library(gridExtra)

setwd("C:/Users/williamslaro/Documents/Research/Projects/Spatial Methods/TLSL/Policy Studies Journal/Replication/Applications/Gilardi and Wasserfallen 2014/")

### Load the Swiss cantons data
swiss = read.dta("Figures/Swiss Cantons.dta", convert.underscore=TRUE)

#############################################################################
### Figure 3: Spatial-Long Term EFfects of a 1-standard deviation increase in deficits per capita in Berne at time t on other Swiss cantons (Model 5)
#############################################################################

t1.0 <- ggplot() + 
	geom_polygon(data=swiss, aes(x=.X, y=.Y, group = .ID, fill = slte.theta1.tp0), color="white") +
	geom_text(aes(x = 7.8, y = 46.7, label = "Berne"), color = "red", size = 12) +
	xlab("") + ylab("") + theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank(), legend.position = "none") +
	scale_fill_gradient(low = "gray90", high = "gray10") 
t1.0

t1.1 <- ggplot() + 
	geom_polygon(data=swiss, aes(x=.X, y=.Y, group = .ID, fill = slte.theta1.tp1), color="white") +
	geom_text(aes(x = 7.8, y = 46.7, label = "Berne"), color = "red", size = 12) +
	xlab("") + ylab("") + theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank(), legend.position = "none") +
	scale_fill_gradient(low = "gray90", high = "gray10") 
t1.1

t1.2 <- ggplot() + 
	geom_polygon(data=swiss, aes(x=.X, y=.Y, group = .ID, fill = slte.theta1.tp2), color="white") +
	geom_text(aes(x = 7.8, y = 46.7, label = "Berne"), color = "red", size = 12) +
	xlab("") + ylab("") + theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank(), legend.position = "none") +
	scale_fill_gradient(low = "gray90", high = "gray10") 
t1.2

t1.3 <- ggplot() + 
	geom_polygon(data=swiss, aes(x=.X, y=.Y, group = .ID, fill = slte.theta1.tp3), color="white") +
	geom_text(aes(x = 7.8, y = 46.7, label = "Berne"), color = "red", size = 12) +
	xlab("") + ylab("") + theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank(), legend.position = "none") +
	scale_fill_gradient(low = "gray90", high = "gray10") 
t1.3
