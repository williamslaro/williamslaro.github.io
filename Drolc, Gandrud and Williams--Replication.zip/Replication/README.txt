***********************************************************************************************************
This folder contains all of the files needed to run the simulations, replicate the empirical results and create the figures in Cody Drolc, Christopher Gandrud and Laron K. Williams, "Taking Time (and Space) Seriously: How Scholars Falsely Infer Policy Diffusion from Model Misspecification", Policy Studies Journal.

If you have questions please contact me at williamslaro@missouri.edu.

The folder contains the following files:

1) Experiments folder containing the replication materials for two sets of Monte Carlo experiments:
	--Scenarios contains the effects of model misspecification (i.e., including unnecessary TLSLs) of different scenarios; this is discussed extensively in the manuscript.
	--Multiple Ws contains the simulations for model misspecification in the face of multiple avenues of policy diffusion:
		--Generate\Monte Carlo Experiments -- SLX with Multiple Ws.do: Stata script file that produces the Monte Carlo simulations 
		--Data\SLX with Multiple Ws.dta: Stata dataset containing the results of the Monte Carlo simulations
		--Programs\SLX Programs.do: Stata script file that contains original programs to produce direct, total, and indirect effects from the SLX models
		--Analyze\Monte Carlo Experiments -- Analyze.do: Stata do file that analyzes the patterns in the Monte Carlo simulations (this produces the Figures\Data\SLX.dta file).
		--Analyze\SLX with Multiple Ws -- Analyze.smcl: Stata log file containing an exact copy of the patterns in the Monte Carlo simulations

2) Survey folder contains the following:
	--Excel file containing the details of the survey (Policy_Diffusion_Survey.do)
	--R script file producing the patterns in the survey (analyze_survey.R)

3) Figures folder contains the following:
	--Stata dataset containing the results of some additional Monte Carlo simulations (dealing with model misspecification in the presence of multiple avenues of policy diffusion)
	--R script file which produces Figures A.2-A.4 in the Appendix (Generate MC Experiments Figures.R), which describes the patterns in the additional MC simulations.

4) Applications folder contains three subfolders, each of which contains the replication materials for that application:
	--Gilardi and Wasserfallen 2016: 
		--Analyze: Stata script file (Gilardi and Wasserfallen 2016 -- Replication.do), Stata log file containing a copy of the empirical analysis (Gilardi and Wasserfallen 2016 -- Replication.smcl) 
		--Data: Stata dataset (Gilardi and Wasserfallen 2016 -- Data.dta), Switzerland shape files (in Switzerland folder) needed to make illustrative map, and all the weights matrices (in the W folder)
		--Figures: Stata data containing the illustrative results for Swiss cantons (Swiss Cantons.dta), and R script with the commands needed to make that figure (Gilardi and Wasserfallen 2016 -- Figures.R)
	--Hollyer, Rosendorff and Vreeland 2011:
		--Analyze: Stata script file (Hollyer, Rosendorff and Vreeland 2011 -- Replication.do) and Stata log file containing a copy of the empirical analysis (Hollyer, Rosendorff and Vreeland 2011 -- Replication.smcl)
		--Data: Stata dataset (Hollyer, Rosendorff and Vreeland 2011 -- Data.dta)
	--Lipsmeyer and Zhu 2011:
		--Analyze: Stata script file (Lipsmeyer and Zhu 2011 -- Replication.do) and Stata log file containing a copy of the empirical analysis (Lipsmeyer and Zhu 2011 -- Replication.smcl)
		--Data: Stata dataset (Lipsmeyer and Zhu 2011 -- Data.dta)

***********************************************************************************************************