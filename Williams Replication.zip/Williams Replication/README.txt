##############################################################################################
### This zipped folder contains all of the files needed to replicate my PSRM, "Opposition Parties and the Timing of Successful No-Confidence Motions"
###
### Laron K. Williams
### University of Missouri
### williamslaro@missouri.edu
###
##############################################################################################

The zipped folder contains the following files:

1) "Legislative Success--Additional Materials.pdf": file containing additional empirical models referenced in the manuscript.

2) "Williams PSRM.dta": Stata data set 

3) "Williams PSRM--Replication.do": Stata do file containing the estimation, substantive effects, robustness checks and descriptive statistics.

4) "Williams PSRM--Programs.do": Stata do file containing the user-defined programs needed to estimate the statistical backwards induction in the "Williams PSRM--Replication.do" file.

5) "Williams PSRM--Figures Replication.R": R script file containing the code to replicate Figures 2-6 in the manuscript.  This figure calls the following data files:
	a) "prob_p.csv" (Figure 2)
	b) "prob_a.csv" (Figure 3)
	c) "pr_tenure.dta" (Figure 4)
	d) "pr_ciep.dta" (Figure 5)
	e) "pr.dta" (Figure 6)
* The files for Figures 2-3 are created by hand while the files for Figures 4-6 are created in the "Williams PSRM--Replication.do" file.

6) "Williams PSRM.smcl": Stata log file containing a precise replication of all the results.


