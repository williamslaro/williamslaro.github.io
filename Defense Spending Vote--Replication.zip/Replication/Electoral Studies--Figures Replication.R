##=============================================================================#
## Code to replicate the figures for the "Estimating the Defense Spending Vote", Electoral Studies R&R
## 
## Created : 12-22-14
## Modified: 
##=============================================================================#

rm(list=ls())
require(lattice)
require(MASS)
require(ggplot2)
require(gridBase)
require(gridExtra)
library(foreign)

# Set up working directory
#setwd("")

###############################################################################################
## Defense spending vote
###############################################################################################
d <- read.dta("DSV.dta", convert.underscore=TRUE)

pdf(file="dsv.pdf", family="Times")
dsv <- ggplot(d, aes(id, pr, ymin = lo, ymax = hi)) + geom_pointrange() + geom_hline(aes(yintercept=0), linetype="dashed") + xlab("Party Identifier") + ylab("Defense Spending Vote")
dsv <- dsv + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
dsv
dev.off()

###############################################################################################
## Partisan emphasis and the defense spending vote
###############################################################################################
ls = 0.7

p <- ggplot(d, aes(rile, pr, ymin = lo, ymax = hi)) + geom_pointrange(linesize=ls) + xlab("Ideology") + ylab("Defense Spending Vote")
p <- p + stat_smooth(method = "lm", aes(weight=1/se))+ geom_hline(aes(yintercept=0), linetype="dashed")
p <- p + geom_rug(data = d, aes(x = rile, position = "jitter"), sides="b")
p <- p + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
p

m <- ggplot(d, aes(milspend, pr, ymin = lo, ymax = hi)) + geom_pointrange(linesize=ls) + xlab("Defense Spending Emphasis") + ylab("")
m <- m + stat_smooth(method = "lm", aes(weight=1/se))+ geom_hline(aes(yintercept=0), linetype="dashed")
m <- m + geom_rug(data = d, aes(x = milspend, position = "jitter"), sides="b")
m <- m + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
m

pdf(file="dsv_p.pdf", family="Times")
grid.newpage()
pushViewport(viewport(layout = grid.layout(1,2)))

vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(p, vp = vplayout(1, 1))
print(m, vp = vplayout(1, 2))
dev.off()

###############################################################################################
## Partisan emphasis and the defense spending vote: across international hostilities
###############################################################################################
d0 <- subset(d, mid.count.h.36==0)
d1 <- subset(d, mid.count.h.36>0)

p0 <- ggplot(d0, aes(rile, pr, ymin = lo, ymax = hi)) + geom_pointrange(linesize=ls) + xlab("") + ylab("Defense Spending Vote")
p0 <- p0 + stat_smooth(method = "lm", aes(weight=1/se))+ geom_hline(aes(yintercept=0), linetype="dashed") + xlim(-50, 50) + ylim(-0.5, 0.5)
p0 <- p0 + geom_rug(data = d0, aes(x = rile, position = "jitter"), sides="b")
p0 <- p0 + ggtitle("No Disputes")
p0 <- p0 + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
p0

p1 <- ggplot(d1, aes(rile, pr, ymin = lo, ymax = hi)) + geom_pointrange(linesize=ls) + xlab("Ideology") + ylab("Defense Spending Vote")
p1 <- p1 + stat_smooth(method = "lm", aes(weight=1/se))+ geom_hline(aes(yintercept=0), linetype="dashed") + xlim(-50, 50) + ylim(-0.5, 0.5)
p1 <- p1 + geom_rug(data = d1, aes(x = rile, position = "jitter"), sides="b")
p1 <- p1 + ggtitle("Disputes")
p1 <- p1 + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
p1

m0 <- ggplot(d0, aes(milspend, pr, ymin = lo, ymax = hi)) + geom_pointrange(linesize=ls) + xlab("") + ylab("")
m0 <- m0 + stat_smooth(method = "lm", aes(weight=1/se)) + geom_hline(aes(yintercept=0), linetype="dashed") + xlim(-15, 10) + ylim(-0.5, 0.5)
m0 <- m0 + geom_rug(data = d0, aes(x = milspend, position = "jitter"), sides="b")
m0 <- m0 + ggtitle("No Disputes")
m0 <- m0 + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
m0

m1 <- ggplot(d1, aes(milspend, pr, ymin = lo, ymax = hi)) + geom_pointrange(linesize=ls) + xlab("Defense Spending Emphasis") + ylab("")
m1 <- m1 + stat_smooth(method = "lm", aes(weight=1/se))+ geom_hline(aes(yintercept=0), linetype="dashed") + xlim(-15, 10) + ylim(-0.5, 0.5)
m1 <- m1 + geom_rug(data = d1, aes(x = milspend, position = "jitter"), sides="b")
m1 <- m1 + ggtitle("Disputes")
m1 <- m1 + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
m1

pdf(file="dsv_ph.pdf", family="Times")
grid.newpage()
pushViewport(viewport(layout = grid.layout(2,2)))

vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(p0, vp = vplayout(1, 1))
print(m0, vp = vplayout(1, 2))
print(p1, vp = vplayout(2, 1))
print(m1, vp = vplayout(2, 2))
dev.off()

###############################################################################################
## Box-whisker plots of defense spending vote across partisanship and PM parties
###############################################################################################
d1 <- read.dta("DSV1.dta", convert.underscore=TRUE)
d2 <- read.dta("DSV2.dta", convert.underscore=TRUE)

lr <- ggplot(d1, aes(factor(lr.pm), pr)) + geom_boxplot() + geom_hline(aes(yintercept=0), linetype="dashed") + ylab("Defense Spending Vote") + xlab("") #
lr <- lr + theme(axis.text.x = element_text(angle = 45, hjust = 1))
lr <- lr + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
lr

lrr <- ggplot(d2, aes(factor(lr.pm2), pr)) + geom_boxplot() + geom_hline(aes(yintercept=0), linetype="dashed") + ylab("") + xlab("") #
lrr <- lrr + theme(axis.text.x = element_text(angle = 45, hjust = 1))
lrr <- lrr + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
lrr

pdf(file="dsv_pm.pdf", family="Times")
grid.newpage()
pushViewport(viewport(layout = grid.layout(1,2)))

vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(lr, vp = vplayout(1, 1))
print(lrr, vp = vplayout(1, 2))
dev.off()

###############################################################################################
## Income quartile vote (1 --> 4)
###############################################################################################
i <- read.dta("IV.dta", convert.underscore=TRUE)

pdf(file="iv.pdf", family="Times")
iv <- ggplot(i, aes(id, pr, ymin = lo, ymax = hi)) + geom_pointrange() + geom_hline(aes(yintercept=0), linetype="dashed") + xlab("Party Identifier") + ylab("Income Quartile Vote")
iv <- iv + opts(axis.text.y = theme_text(family = "serif", hjust = 1), axis.text.x = theme_text(family = "serif"), axis.title.y = theme_text(family = "serif", face = "bold", size = 12, angle = 90), axis.title.x = theme_text(family = "serif", face = "bold", size = 12))
iv
dev.off()


