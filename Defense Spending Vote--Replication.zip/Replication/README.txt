##############################################################################################################
This is the replication file for "Estimating the Defense Spending Vote", Electoral Studies, Laron K. Williams.

Any questions, please email me at williamslaro@missouri.edu
##############################################################################################################

The following files are included in the zipped folder:

1) "Micro Replication.do": Stata do file that uses the "ISSP--Defense Spending.dta" file and estimates the survey-specific MNL models.  It also merges in variables from the "CMP--Full.csv" file and the "WKB_update_v5.csv" file.

2) "ISSP--Defense Spending.dta": individual-level Stata data set of aggregated ISSP data used for the MNL models.

3) "ISSP--Defense Spending--Vote Choice.dta": macro-level Stata data set containing the defense spending vote estimates for each party in the MNL models.

4) "ISSP--Income--Vote Choice.dta": similar to the data set above, but this one contains the estimates of the change in probabilities of voting for each party, given an increase in income quartile from 1 to 4 (shown in the Additional Materials file).

5) "DSV.dta": Stata data set that is created by the "Micro Replication.do" file and is used to produce the figures.

6) "IV.dta", "DSV1.dta", and "DSV2.dta": Stata data sets used to produce the figures. 

7) "Macro Replication.do": Stata do file that uses the "DSV.dta" file to estimate a series of robustness checks.

8) "Electoral Studies--Figures Replication.R": R script file containing the code necessary to replicate the figures in the manuscript and Additional Materials file (uses the "DSV.dta", "DSV1.dta", "DSV2.dta", and "IV.dta" files).

9) Stata log files containing the replicated output of the MNL models ("Defense Spending--Models.smcl"), robustness checks ("Defense Spending--Robustness Checks.smcl") and descriptive statistics ("Defense Spending--Descriptive Statistics.smcl").

