This folder contains all of the files needed to replicate the models and figures in the manuscript and additional materials file for the "You've Got Some Explaining To Do: The Influence of Economic Conditions and Spatial Competition on Party Strategy", Laron K. Williams, Katsunori Seki and Guy D. Whitten, Political Science Research & Methods.

FILES:
1) "Williams Seki and Whitten--Replication.do": Stata do file that replicates the results contained in the manuscript and additional materials document.

2) "Williams Seki and Whitten--Replication.smcl": Stata log file that shows the replicated results.

3) "Williams Seki and Whitten.dta": Stata data set used to estimate the models.

4) "W1.dta" and "W2.dta": two weights matrices called by the spatreg command.

5) "Williams Seki and Whitten--Graphs Replication.R": file to replicate the figures in the manuscript and AM file.

6) "ME_un1.csv", "ME_un2.csv", "gperc.dta", and "fmpm.csv": files created in the Stata do file ("Williams Seki and Whitten--Replication.do") and used in the "Williams Seki and Whitten--Graphs Replication.R" file to create the figures.


NOTES:
1) To recreate the models, you need to have the spatreg package installed (findit spatreg).

2) You also need to have run the programs located at the bottom of the replication file (in the ****Programs***** section).  

3) All of the files need to be in the same working directory. 

4) The spatreg commands call on two weights matrices: W1.dta and W2.dta.

5) The section of commands that estimate Model 1 also produce a .csv file containing the coefficients from that model; this csv file will be used when generating the figures.

6) The figures are created in R with the "Williams Seki and Whitten--Graphs Replication.R" file.  The R file will call on the following data sets, which also must be in the working directory specified in the R file:
	a) "gperc.dta": this data set is created with the "me_g" command, which is in the ****Substantive Effects**** section of the Stata replication file.
	b) "fmpm.csv": this csv file is hand-inputted based on the marginal effects (and CIs) produced by the "me_pmfm" command in the Model 3 section of the Stata replication file.
	c) "ME_un1.csv": this contains the predicted values for Figure 3.  To create this file (and the one below), you need to access the "b_W1.csv" file, which is created in the Model 1 section of the Stata replication file.
	b) "ME_un2.csv": this contains the predicted values for Figure 4.

If you have any questions about the replication materials, please email the corresponding author (Laron K. Williams) at williamslaro@missouri.edu

