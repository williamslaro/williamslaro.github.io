################################################################################
################################################################################
## Code to produce the figures used in "You've Got Some Explaining To Do: The Influence of Economic Conditions and Spatial Competition on Party Strategy"
## Laron K. Williams, Katsunori Seki and Guy D. Whitten
## Political Science Research & Methods
##
## Created: 2-20-13
## Modified: 5-28-14
##
################################################################################
################################################################################

library(foreign)
library(ggplot2)
library(grid)
library(gridBase)
require(MASS)
library(gridExtra)


# set up working directory
#setwd("")

#######################################################################################
### Figure 1: Marginal effects of unemployment and inflation on economic emphasis across values of percentage of government seats
#######################################################################################
gperc = read.dta("gperc.dta", convert.underscore=TRUE)

u <- ggplot(gperc, aes(x = xaxis)) + geom_line(aes(x = xaxis, y = me.u)) + geom_line(aes(x = xaxis, y = lo.u, type = 2), linetype = "dashed") + geom_line(aes(x = xaxis, y = hi.u), linetype = "dashed") + geom_hline(yintercept = 0)
u <- u + xlab("Percentage of Government Seats") + ylab("Economic Emphasis") + ggtitle("Unemployment") + theme(plot.title = element_text(family="serif", size = 18)) + theme(axis.title.x = element_text(family="serif", size = 12)) + theme(axis.title.y = element_text(family="serif", size = 12))
u

i <- ggplot(gperc, aes(x = xaxis)) + geom_line(aes(x = xaxis, y = me.i)) + geom_line(aes(x = xaxis, y = lo.i), linetype = "dashed")  + geom_line(aes(x = xaxis, y = hi.i), linetype = "dashed") + geom_hline(yintercept = 0)
i <- i + xlab("Percentage of Government Seats") + ylab("") + ggtitle("Inflation") + theme(plot.title = element_text(family="serif", size = 18)) + theme(axis.title.x = element_text(family="serif", size = 12)) + theme(axis.title.y = element_text(family="serif", size = 12))
i

grid.newpage()
pushViewport(viewport(layout = grid.layout(1,2)))

vplayout <- function(x, y)
	viewport(layout.pos.row = x, layout.pos.col = y)
print(u, vp = vplayout(1, 1))
print(i, vp = vplayout(1, 2))

#######################################################################################
### Figure 2: Marginal effects of unemployment and inflation on economic emphasis across the Prime Minister's party and ownership of the finance portfolio
#######################################################################################
me <- read.csv("fmpm.csv", sep=",", header=TRUE)
meu <- subset(me, econ == 1)
mei <- subset(me, econ == 2)

mat <- matrix(NA,4,ncol=6)
colnames(mat) <- c("me","lower","upper")
data.matrix(meu)
mat[,1] <- meu[,3]
mat[,2] <- meu[,6]
mat[,3] <- meu[,7]
mat[,4] <- mei[,3]
mat[,5] <- mei[,6]
mat[,6] <- mei[,7]

lwd=2
ptype <- 20
psize <- 1.5
cexp=.8
shadeColor <- c("gray85", "gray92")

################## Unemployment #######################
## graphic parameters
ylim <- c(-.5, 1)    # y-axis range
xlim <- c(0.5, 4.5)  # x-axis range

par(fig=c(0,0.55,0,1), mar=c(2,3.5,1.5,1))
plot(0,0,type="n",xlim=xlim,ylim=ylim,axes=F,ann=F,cex=cexp)

### shades
yrng <- c(ylim[1],ylim[2],ylim[2],ylim[1])

polygon(x=c(1.5,1.5,0.5,0.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(2.5,2.5,1.5,1.5), y=yrng,col=shadeColor[2], border=F)
polygon(x=c(3.5,3.5,2.5,2.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(4.5,4.5,3.5,3.5), y=yrng,col=shadeColor[2], border=F)

### vertical dotted line at 0
abline(h=0,lty="dotted",col="black")

### lines
for(i in 1:4){
  z <- (i - 1)
  points(y=mat[i,1],x=i,pch=ptype,bg="white",cex=psize)
  lines(y=c(mat[i,2],mat[i,3]), x=c(i,i),lwd=lwd)
}

mod.names <- c("Neither", "FM Only", "PM Only", "FM & PM")
xlabd2 <- c(1, 2, 3, 4)

### axis
xlabd <- c("-0.5", "0", "0.5", "1")
axis(2,cex.axis=0.8, mgp=c(3,1.1,0), labels=xlabd,at=xlabd)
axis(1, cex.axis=0.7, mgp=c(3,.6,0), labels=mod.names, at=xlabd2)
mtext("Economic Emphasis", 2, line = 2, cex=1.25, las=0, padj=0, family="serif")
mtext("Unemployment", 3, line = -0.5, cex=1.25, las=1, padj=0, family="serif")

################## Inflation #######################
## graphic parameters
ylim <- c(-1, 1.5)    # y-axis range
xlim <- c(0.5, 4.5)  # x-axis range

par(fig=c(0.55,1,0,1), mar=c(2,1,1.5,.5), new=TRUE)
plot(0,0,type="n",xlim=xlim,ylim=ylim,axes=F,ann=F,cex=cexp)

### shades
yrng <- c(ylim[1],ylim[2],ylim[2],ylim[1])

polygon(x=c(1.5,1.5,0.5,0.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(2.5,2.5,1.5,1.5), y=yrng,col=shadeColor[2], border=F)
polygon(x=c(3.5,3.5,2.5,2.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(4.5,4.5,3.5,3.5), y=yrng,col=shadeColor[2], border=F)

### vertical dotted line at 0
abline(h=0,lty="dotted",col="black")

### lines
for(i in 1:4){
  z <- (i - 1)
  points(y=mat[i,4],x=i,pch=ptype,bg="white",cex=psize)
  lines(y=c(mat[i,5],mat[i,6]), x=c(i,i),lwd=lwd)
}

mod.names <- c("Neither", "FM Only", "PM Only", "FM & PM")
xlabd2 <- c(1, 2, 3, 4)

### axis
xlabd <- c("-1", "-0.5", "0", "0.5", "1", "1.5")
axis(2,cex.axis=0.8, mgp=c(3,1.1,0), labels=xlabd,at=xlabd)
axis(1, cex.axis=0.7, mgp=c(3,.6,0), labels=mod.names, at=xlabd2)
mtext("Inflation", 3, line = -0.5, cex=1.25, las=1, padj=0, family="serif")



################################################################################
### Figure 3: Marginal effect of a 1-standard deviation increase in unemployment for a government party across five scenarios of economic emphasis by ideologically-proximate parties
################################################################################
b <- read.csv("ME_un1.csv", sep=",", header=TRUE) 
b

xlim <- c(0.5,5.5)    # x-axis range
ylim <- c(0.9,1.5)  # y-axis range

cexp <- 0.8

par(fig=c(0,1,0.55,1),mar=c(.25,4,.5,1))
plot(b$v, b$me, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")

points(b$v, b$me, pch=19)
mtext("Predicted Economic Emphasis", 2, line = 2, cex=cexp)

par(fig=c(0,1,0,0.55),mar=c(.25,4,1.5,1), new=TRUE)
plot(b$v, b$me, xlim=xlim, ylim=xlim, ann=F, type="n",axes=FALSE)

at <- c(1.4,2.4,3.0,3.6,4.6)
lab <- c("-40","-15","0","15","40")

axis(side=2, at=at, labels=lab, cex=.5)
mtext("Left-Right Position", 2, line = 2, cex=cexp)

### First scenario
segments(1,1,1,5,lty=1,lwd=3)
segments(0.8,1,1.2,1,lty=1,lwd=3)
segments(0.8,5,1.2,5,lty=1,lwd=3)

text(1,5.25, "XB", cex=cexp, font=2) 

segments(1,3,1.1,3,lty=1,lwd=2)
text(1.3,3,"G",cex=cexp,font=2)

segments(1,4.6,.95,4.6,lty=1,lwd=3)
segments(1,1.4,.95,1.4,lty=1,lwd=3)

segments(1,3.6,.5,3.6,lty=1,lwd=3)
segments(1,2.4,.5,2.4,lty=1,lwd=3)

### Second scenario
segments(2,1,2,5,lty=1,lwd=3)
segments(1.8,1,2.2,1,lty=1,lwd=3)
segments(1.8,5,2.2,5,lty=1,lwd=3)

text(2,5.25, "XB", cex=cexp, font=2) 

segments(2,3,2.1,3,lty=1,lwd=2)
text(2.3,3,"G",cex=cexp,font=2)

segments(2,4.6,1.95,4.6,lty=1,lwd=3)
segments(2,1.4,1.95,1.4,lty=1,lwd=3)

segments(2,3.6,1.85,3.6,lty=1,lwd=3)
segments(2,2.4,1.85,2.4,lty=1,lwd=3)

### Third scenario
segments(3,1,3,5,lty=1,lwd=3)
segments(2.8,1,3.2,1,lty=1,lwd=3)
segments(2.8,5,3.2,5,lty=1,lwd=3)

text(3,5.25, "XB", cex=cexp, font=2) 

segments(3,3,3.1,3,lty=1,lwd=2)
text(3.3,3,"G",cex=cexp,font=2)

### Fourth scenario
segments(4,1,4,5,lty=1,lwd=3)
segments(3.8,1,4.2,1,lty=1,lwd=3)
segments(3.8,5,4.2,5,lty=1,lwd=3)

text(4,5.25, "XB", cex=cexp, font=2) 

segments(4,3,4.1,3,lty=1,lwd=2)
text(4.3,3,"G",cex=cexp,font=2)

segments(4,4.6,3.95,4.6,lty=1,lwd=3)
segments(4,1.4,3.95,1.4,lty=1,lwd=3)

segments(4,3.6,4.15,3.6,lty=1,lwd=3)
segments(4,2.4,4.15,2.4,lty=1,lwd=3)

### Fifth scenario
segments(5,1,5,5,lty=1,lwd=3)
segments(4.8,1,5.2,1,lty=1,lwd=3)
segments(4.8,5,5.2,5,lty=1,lwd=3)

text(5,5.25, "XB", cex=cexp, font=2) 

segments(5,3,5.1,3,lty=1,lwd=2)
text(5.3,3,"G",cex=cexp,font=2)

segments(5,4.6,4.95,4.6,lty=1,lwd=3)
segments(5,1.4,4.95,1.4,lty=1,lwd=3)

segments(5,3.6,5.5,3.6,lty=1,lwd=3)
segments(5,2.4,5.5,2.4,lty=1,lwd=3)



################################################################################
### Figure 4: Marginal effect of a one-standard deviation increase in unemployment for a government party across five scenarios of economic emphasis by ideologically-extreme parties.
################################################################################
b <- read.csv("ME_un2.csv", sep=",", header=TRUE) 
b

xlim <- c(0.5,5.5)    # x-axis range
ylim <- c(0.9,1.5)  # y-axis range

cexp <- 0.8

par(fig=c(0,1,0.55,1),mar=c(.25,4,.5,1))
plot(b$v, b$me, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
points(b$v, b$me, pch=19)
mtext("Predicted Economic Emphasis", 2, line = 2, cex=cexp)

par(fig=c(0,1,0,0.55),mar=c(.25,4,1.5,1), new=TRUE)
plot(b$v, b$me, xlim=xlim, ylim=xlim, ann=F, type="n",axes=FALSE)

at <- c(1.4,2.4,3.0,3.6,4.6)
lab <- c("-40","-15","0","15","40")

axis(side=2, at=at, labels=lab, cex=.5)
mtext("Left-Right Position", 2, line = 2, cex=cexp)

### First scenario
segments(1,1,1,5,lty=1,lwd=3)
segments(0.8,1,1.2,1,lty=1,lwd=3)
segments(0.8,5,1.2,5,lty=1,lwd=3)

text(1,5.25, "XB", cex=cexp, font=2) 

segments(1,3,1.1,3,lty=1,lwd=2)
text(1.3,3,"G",cex=cexp,font=2)

segments(1,4.6,.5,4.6,lty=1,lwd=3)
segments(1,1.4,.5,1.4,lty=1,lwd=3)

segments(1,3.6,.95,3.6,lty=1,lwd=3)
segments(1,2.4,.95,2.4,lty=1,lwd=3)

### Second scenario
segments(2,1,2,5,lty=1,lwd=3)
segments(1.8,1,2.2,1,lty=1,lwd=3)
segments(1.8,5,2.2,5,lty=1,lwd=3)

text(2,5.25, "XB", cex=cexp, font=2) 

segments(2,3,2.1,3,lty=1,lwd=2)
text(2.3,3,"G",cex=cexp,font=2)

segments(2,4.6,1.85,4.6,lty=1,lwd=3)
segments(2,1.4,1.85,1.4,lty=1,lwd=3)

segments(2,3.6,1.95,3.6,lty=1,lwd=3)
segments(2,2.4,1.95,2.4,lty=1,lwd=3)

### Third scenario
segments(3,1,3,5,lty=1,lwd=3)
segments(2.8,1,3.2,1,lty=1,lwd=3)
segments(2.8,5,3.2,5,lty=1,lwd=3)

text(3,5.25, "XB", cex=cexp, font=2) 

segments(3,3,3.1,3,lty=1,lwd=2)
text(3.3,3,"G",cex=cexp,font=2)

### Fourth scenario
segments(4,1,4,5,lty=1,lwd=3)
segments(3.8,1,4.2,1,lty=1,lwd=3)
segments(3.8,5,4.2,5,lty=1,lwd=3)

text(4,5.25, "XB", cex=cexp, font=2) 

segments(4,3,4.1,3,lty=1,lwd=2)
text(4.3,3,"G",cex=cexp,font=2)

segments(4,4.6,4.15,4.6,lty=1,lwd=3)
segments(4,1.4,4.15,1.4,lty=1,lwd=3)

segments(4,3.6,3.95,3.6,lty=1,lwd=3)
segments(4,2.4,3.95,2.4,lty=1,lwd=3)

### Fifth scenario
segments(5,1,5,5,lty=1,lwd=3)
segments(4.8,1,5.2,1,lty=1,lwd=3)
segments(4.8,5,5.2,5,lty=1,lwd=3)

text(5,5.25, "XB", cex=cexp, font=2) 

segments(5,3,5.1,3,lty=1,lwd=2)
text(5.3,3,"G",cex=cexp,font=2)

segments(5,4.6,5.5,4.6,lty=1,lwd=3)
segments(5,1.4,5.5,1.4,lty=1,lwd=3)

segments(5,3.6,4.95,3.6,lty=1,lwd=3)
segments(5,2.4,4.95,2.4,lty=1,lwd=3)







#######################################################################################
#######################################################################################
########################## Additional Materials #######################################
#######################################################################################
#######################################################################################

#######################################################################################
### Figure S.1: Marginal effect of GDP across government seats (%)
#######################################################################################
g <- ggplot(gperc, aes(x = xaxis)) + geom_line(aes(x = xaxis, y = me.g)) + geom_line(aes(x = xaxis, y = lo.g), linetype = "dashed")  + geom_line(aes(x = xaxis, y = hi.g), linetype = "dashed") + geom_hline(yintercept = 0)
g <- g + xlab("Percentage of Government Seats") + ylab("Economic Emphasis") + theme(plot.title = element_text(family="serif", size = 18)) + theme(axis.title.x = element_text(family="serif", size = 12)) + theme(axis.title.y = element_text(family="serif", size = 12))
g


#######################################################################################
### Figure S.2: Marginal effects of unemployment and inflation on economic emphasis across the Prime Minister's party and ownership of the finance portfolio
#######################################################################################
me <- read.csv("fmpm.csv", sep=",", header=TRUE)
meu <- subset(me, econ == 1)
mei <- subset(me, econ == 2)

mat <- matrix(NA,4,ncol=6)
colnames(mat) <- c("me","lower","upper")
data.matrix(meu)
mat[,1] <- meu[,3]
mat[,2] <- meu[,4]
mat[,3] <- meu[,5]
mat[,4] <- mei[,3]
mat[,5] <- mei[,4]
mat[,6] <- mei[,5]

lwd=2
ptype <- 20
psize <- 1.5
cexp=.8
shadeColor <- c("gray85", "gray92")

################## Unemployment #######################
## graphic parameters
ylim <- c(-.5, 1)    # y-axis range
xlim <- c(0.5, 4.5)  # x-axis range

par(fig=c(0,0.55,0,1), mar=c(2,3.5,1.5,1))
plot(0,0,type="n",xlim=xlim,ylim=ylim,axes=F,ann=F,cex=cexp)

### shades
yrng <- c(ylim[1],ylim[2],ylim[2],ylim[1])

polygon(x=c(1.5,1.5,0.5,0.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(2.5,2.5,1.5,1.5), y=yrng,col=shadeColor[2], border=F)
polygon(x=c(3.5,3.5,2.5,2.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(4.5,4.5,3.5,3.5), y=yrng,col=shadeColor[2], border=F)

### vertical dotted line at 0
abline(h=0,lty="dotted",col="black")

### lines
for(i in 1:4){
  z <- (i - 1)
  points(y=mat[i,1],x=i,pch=ptype,bg="white",cex=psize)
  lines(y=c(mat[i,2],mat[i,3]), x=c(i,i),lwd=lwd)
}

mod.names <- c("Neither", "FM Only", "PM Only", "FM & PM")
xlabd2 <- c(1, 2, 3, 4)

### axis
xlabd <- c("-0.5", "0", "0.5", "1")
axis(2,cex.axis=0.8, mgp=c(3,1.1,0), labels=xlabd,at=xlabd)
axis(1, cex.axis=0.7, mgp=c(3,.6,0), labels=mod.names, at=xlabd2)
mtext("Economic Emphasis", 2, line = 2, cex=1.25, las=0, padj=0, family="serif")
mtext("Unemployment", 3, line = -0.5, cex=1.25, las=1, padj=0, family="serif")

################## Inflation #######################
## graphic parameters
ylim <- c(-1, 1.5)    # y-axis range
xlim <- c(0.5, 4.5)  # x-axis range

par(fig=c(0.55,1,0,1), mar=c(2,1,1.5,.5), new=TRUE)
plot(0,0,type="n",xlim=xlim,ylim=ylim,axes=F,ann=F,cex=cexp)

### shades
yrng <- c(ylim[1],ylim[2],ylim[2],ylim[1])

polygon(x=c(1.5,1.5,0.5,0.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(2.5,2.5,1.5,1.5), y=yrng,col=shadeColor[2], border=F)
polygon(x=c(3.5,3.5,2.5,2.5), y=yrng,col=shadeColor[1], border=F)
polygon(x=c(4.5,4.5,3.5,3.5), y=yrng,col=shadeColor[2], border=F)

### vertical dotted line at 0
abline(h=0,lty="dotted",col="black")

### lines
for(i in 1:4){
  z <- (i - 1)
  points(y=mat[i,4],x=i,pch=ptype,bg="white",cex=psize)
  lines(y=c(mat[i,5],mat[i,6]), x=c(i,i),lwd=lwd)
}

mod.names <- c("Neither", "FM Only", "PM Only", "FM & PM")
xlabd2 <- c(1, 2, 3, 4)

### axis
xlabd <- c("-1", "-0.5", "0", "0.5", "1", "1.5")
axis(2,cex.axis=0.8, mgp=c(3,1.1,0), labels=xlabd,at=xlabd)
axis(1, cex.axis=0.7, mgp=c(3,.6,0), labels=mod.names, at=xlabd2)
mtext("Inflation", 3, line = -0.5, cex=1.25, las=1, padj=0, family="serif")




