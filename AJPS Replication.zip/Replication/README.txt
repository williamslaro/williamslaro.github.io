This folder contains the replication files for "Don't Stand So Close to Me: Spatial Contagion Effects and Party Competition", by Guy D. Whitten and Laron K. Williams.

In the replication do file ("Whitten and Williams AJPS--Replication.do"), I present the descriptive statistics, and results from the two models in the manuscript and six models in the SI document.
For each of the models, the additional commands create the following data sets (as .csv files), where "W" is the name of the weights matrix:
1) b_"W".csv: this contains the beta matrix for that model.
2) "W"_draws.csv: contains 1000 draws of each coefficient from the model (drawn from a multivariate normal).

In addition to the data set ("Whitten and Williams AJPS.dta"), make sure that you have saved the 8 weights matrices in the working directory:
1) prox_abs_high_clarity_weight2
2) prox_abs_low_clarity_weight2
3) high_clarity_weight2
4) low_clarity_weight2
5) sq_high_clarity_weight2
6) sq_low_clarity_weight2
7) prox_sq_high_clarity_weight2
8) prox_sq_low_clarity_weight2

The exact replication of the results is shown in the Stata log file ("Whitten and Williams AJPS--Replication.smcl").

Make sure that you run the entire "Whitten and Williams AJPS--Programs.do" file first, since it relies on programs created in that additional do file.

The figures in the manuscript and SI are produced by the "Whitten and Williams AJPS--Figures Replication.R" file containing the following data sets (located in the Figures subfolder):
1) Distance.dta
2) Distance_low.dta
3) Distance_high.dta
4) growth_ci.dta
5) spat_ci_low.dta
6) spat_ci_hi.dta
7) netherlands_1994_ci.csv