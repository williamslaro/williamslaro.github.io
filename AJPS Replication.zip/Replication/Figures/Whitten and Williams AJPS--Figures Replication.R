###########################################################################
## Code to produce the figures for the Whitten and Williams "Don't Stand So Close to Me" project.
##
## Created: 3-13-14
##
## NOTE: Make sure that the working directory points to the Figures subfolder; this is where all the data sets are at.
###########################################################################

library(foreign)
library(ggplot2)
library(lattice)
library(fields)

# Set up working directory
setwd("/Replication/Figures/")

################################################################################
### Ideological landscape of Ireland 1981 and Netherlands 1982
### Figure 1
################################################################################

pdf(file="figure1.pdf",fonts="serif")

xlat <- c(-50,0,50)
xlab <- c("Far Left","0","Far Right")
ylat <- c(0, 10, 20, 30)
ylab <- c("0","10","20","30")

cexp <- .9
xlim <- c(-50,50)    # x-axis range
ylim <- c(-2,51)  # y-axis range
ylim2 <- c(-2,31)  # y-axis range

B <- matrix(NA,11,ncol=2)         

v <- -50
y <- -5
for(i in 1:11){
  B[i,1] <- v
  B[i,2] <- y
  v <- (v + 10)
  y <- (y + 5) 
}

par(fig=c(0,1,0.55,1), mar=c(4,4,2,1.5))

plot(B[,1], B[,2], xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
abline(h=0, lty=1, lwd=1.5)

segments(-8.7, 0, x1 = -8.7, y1 = 11.63, lwd=2)
segments(-1.4, 0, x1 = -1.4, y1 = 50.63, lwd=2)
segments(7.4, 0, x1 = 7.4, y1 = 30.49, lwd=2)

text(-16,12, "Labour", cex=cexp) 
text(-11, 50, "Fianna Fail", cex=cexp)
text(17, 30, "Fine Gael", cex=cexp)

points(-8.7, y = 11.65, type = "p", pch=21, cex=2)
points(-1.4, y = 50.65, type = "p", pch=18, col="black", cex=2)
points(7.4, y = 30.52, type = "p", pch=21, cex=2)

axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)
mtext("Party Vote Share", 2, line = 2, cex=cexp)
#mtext("Party's Left-Right Position", 1, line = 2, cex=cexp)
mtext("Ireland 1981: Growth = -1.01%", 3, line = 0.5, las=0, font=2)

### Netherlands 1982
par(fig=c(0,1,0.1,.55), mar=c(4,4,2,1.5), new=TRUE)

plot(B[,1], B[,2], xlim=xlim, ylim=ylim2, ann=F, type="n", xaxt="n", yaxt="n")
abline(h=0, lty=1, lwd=1.5)

segments(-20.7, 0, x1 = -20.7, y1 = 28.29, lwd=2)
segments(-12.6, 0, x1 = -12.6, y1 = 11.06, lwd=2)
segments(-11.7, 0, x1 = -11.7, y1 = 30.81, lwd=2)
segments(-8, 0, x1 = -8, y1 = 1.97, lwd=2)
segments(21, 0, x1 = 21, y1 = 17.32, lwd=2)

text(-28,28, "Labour", cex=cexp) 
text(-17, 11, "D66", cex=cexp)
text(5, 31, "Christian Democrats", cex=cexp)
text(0, 3, "Radicals", cex=cexp)
text(29, 18, "Liberals", cex=cexp)

points(-20.7, y = 28.29, type = "p", pch=18, col="grey", cex=2)
points(-12.6, y = 11.06, type = "p", pch=18, col="grey", cex=2)
points(-11.7, y = 30.81, type = "p", pch=18, col="black", cex=2)
points(-8, y = 1.97, type = "p", pch=21, cex=2)
points(21, y = 17.32, type = "p", pch=21, cex=2)

axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)
axis(2,labels=ylab,at=ylat)
mtext("Party Vote Share", 2, line = 2, cex=cexp)
mtext("Party's Left-Right Position", 1, line = 2, cex=cexp)
mtext("Netherlands 1982: Growth = -1.39%", 3, line = 0.5, las=0, font=2)

### Legend
par(fig=c(0,1,0,0.1), mar=c(.25,3,.25,1), new=TRUE)

yliml <- c(-0.5, 2.5)    # y-axis range
xliml <- c(0.5, 4.5)  # x-axis range

plot(0,0,type="n",xlim=xliml,ylim=yliml,axes=F,ann=F,cex=cexp)
leg.txt <- c("PM's Party", "Coalition Partner			","Opposition Party")
pch_type <- c(18,18,21)
bg_type <- c("","","grey")
col_type <- c("black","grey")
legend(0.75, 2, leg.txt, pch = pch_type, bg = bg_type, col = col_type, cex=1, pt.cex=2, bty="n", ncol=3)

dev.off()


################################################################################
### Marginal effect of GDP across government dummy variable for 4 scenarios
### 2 x 2 table transformed into 4 figures
### SAMPLE: low clarity
### WEIGHTS MATRIX: closest neighbors, absolute distance
### X-axis range: -50 to 50
### Figure 2
################################################################################
b <- read.dta("growth_ci.dta") 

pdf(file="figure2.pdf",fonts="serif")

xlat <- c(-50,-25,0,25,50)
xlab <- c("-50","-25","0","25","50")

cexp <- .9
xlim <- c(-50,50)    # x-axis range
ylim <- c(.65,1)  # y-axis range

par(fig=c(0,1,0.025,1), mar=c(4,4,1.5,1.5))

plot(b$v, b$g_mn, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$g_mn, lty=1)
mtext("Marginal Effect of 1-S.D. Increase in GDP Growth", 2, line = 2, cex=cexp)
mtext("Prime Minister's Party's Left-Right Position", 1, line = 2, cex=cexp)

text(0,.67, "Opposition", cex=cexp, font=2) 
text(0,.655, "(-0.04%)", cex=cexp, font=2) 
axis(side=1,at=0,tck=.02, lty=1, lwd=3, labels="")
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

dev.off()

################################################################################
### Predicted vote share for an opposition party with varying rile; the government party is at 100 (middle)
### First obs is Party A, second obs is Party B
### SIMPLE VERSION: Party A's XB = 0 Party B's XB=-5
### Weights matrix: low clarity, neighbors, absolute distance
### X-axis range: -50 to +50
### 1 x 2 graph: Low clarity compared to high clarity
### Figure 3
################################################################################
hi <- read.dta("spat_ci_hi.dta") 
lo <- read.dta("spat_ci_low.dta") 

xlim <- c(-50,50)    # x-axis range
ylim <- c(-7,3.5)  # y-axis range
yla <- c("-6","-3","0","3")
yla2 <- c("","","","","")
xlat <- c(-50,-25,0,25,50)
xlab <- c("-50","-25","0","25","50")
cexp <- .9

pdf(file="figure3.pdf",fonts="serif")

# High clarity case
par(fig=c(0,.55,0.15,1),mar=c(.25,5,.5,1))
plot(0, 0, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
lines(hi$v, hi$o_mn, lty=1)
lines(hi$v, hi$g_mn, lty=2)
axis(1,cex.axis=cexp, mgp=c(3,.4,0), labels=xlab,at=xlat)
axis(2,labels=yla,at=yla,las=1,cex.axis=cexp)
mtext("Party A's Left-Right Position", 1, line = 1.5, las=0)
mtext("Predicted Vote Change", 2, line = 2.5)
mtext(expression(paste("High Clarity (",rho,"= -.004)")), 3, line = -1.5, las=0)
text(0,-7, "Party B", cex=cexp, font=2) 
axis(side=1,at=0,tck=.02, lty=1, lwd=3, cex=cexp,labels=c(""))

# Low clarity case
par(fig=c(0.55,1,0.15,1),mar=c(.25,1,.5,1),new=TRUE)
plot(0, 0, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
lines(lo$v, lo$o_mn, lty=1)
lines(lo$v, lo$g_mn, lty=2)
axis(1,cex.axis=cexp, mgp=c(3,.4,0), labels=xlab,at=xlat)
axis(2,labels=yla,at=yla,las=1,cex.axis=cexp)
mtext("Party A's Left-Right Position", 1, line = 1.5, las=0)
mtext(expression(paste("Low Clarity (",rho,"= -.012)")), 3, line = -1.5, las=0)
text(0,-7, "Party B", cex=cexp, font=2) 
axis(side=1,at=0,tck=.02, lty=1, lwd=3, cex=cexp,labels=c(""))
  
# Legend
par(fig=c(0,1,0,.15), new=TRUE, mar=c(1,4,1,1))
plot(0,0,xlim=xlim,ylim=ylim,cex=cexp,type="n",axes=F,ann=F)
leg.txt <- c(expression(paste("Party A: X",beta,"= 0%")), expression(paste("Party B: X",beta,"= -5%")))
lty.type <- c(1,2)
legend(-35, -1.5, leg.txt, lty=lty.type, cex=1, ncol=2, lwd=1, bty="n")

dev.off()


################################################################################
### Predicted vote change for Netherlands 1994
### 2 x 2 table
### SAMPLE: low clarity only
### WEIGHTS MATRIX: closest neighbors, absolute distance
### X-axis range: -50 to +50
### Figure 4
################################################################################
b <- read.csv("netherlands_1994_ci.csv", sep=",", header=TRUE) 

summary(b$pvda)
summary(b$d66)
summary(b$cda)
summary(b$vvd)

cexp <- .7
xlat <- c(-50,-25,0,25,50)
xlab <- c("-50","-25","0","25","50")

pdf(file="figure4.pdf",fonts="serif")

### PvdA
xlim <- c(-50,50)    # x-axis range
ylim <- c(-3,-1.5)  # y-axis range

par(fig=c(0,.5,0.55,1),mar=c(.25,4,.5,1))
plot(b$v, b$pvda, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$pvda, lty=1)
mtext("Predicted Vote Change", 2, line = 2, cex=cexp)
mtext("PvdA's Left-Right Position", 1, line = 2, cex=cexp)

fp <- 4.26 # focal party's position
p1 <- -10
p2 <- -2.59 
p3 <- 15.12
e1 <- "(+0.8)"
e2 <- "(-2.2)"
e3 <- "(+0.9)"
ploc <- -2.86
vloc <- -2.95

axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

abline(v=fp, lty=2, lwd=2)
text(-13,-2.75, "D'66", cex=cexp, font=2) 
text(-13,-2.84, e1, cex=cexp, font=2) 
axis(side=1, at=p1, labels="", tck=.1, lty=1, lwd=3)

text(-1,ploc, "CDA", cex=cexp, font=2) 
text(-1,vloc, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.02, lty=1, lwd=3)

text(p3,ploc, "VVD", cex=cexp, font=2) 
text(p3,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)

### D'66
ylim <- c(0.25,2.5)  # y-axis range

par(fig=c(.5,1,0.55,1), new=TRUE, mar=c(.25,1.5,.5,1))
plot(b$v, b$d66, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$d66, lty=1)
mtext("D'66's Left-Right Position", 1, line = 2, cex=cexp)

fp <- -8.24 # focal party's position
p1 <- 4.26
p2 <- -2.59 
p3 <- 15.12
e1 <- "(-2.0)"
e2 <- "(-2.2)"
e3 <- "(+0.9)"
ploc <- .44
vloc <- .32

abline(v=fp, lty=2, lwd=2)
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

text(p1,.65, "PvdA", cex=cexp, font=2) 
text(p1,.53, e1, cex=cexp, font=2) 
axis(side=1, at=p1, labels="", tck=.1, lty=1, lwd=3)

text(-3.8,ploc, "CDA", cex=cexp, font=2) 
text(-3.6,vloc, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.02, lty=1, lwd=3)

text(p3,ploc, "VVD", cex=cexp, font=2) 
text(p3,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)

###  CDA
ylim <- c(-3.5,-2)  # y-axis range

par(fig=c(0,.5,0,0.5), new=TRUE, mar=c(3.25,4,1.5,1))
plot(b$v, b$cda, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$cda, lty=1)
mtext("Predicted Vote Change", 2, line = 2, cex=cexp)
mtext("CDA's Left-Right Position", 1, line = 2, cex=cexp)

fp <- -2.59 # focal party's position
p1 <- 4.26
p2 <- 15.12 
p3 <- -8.24
e1 <- "(-2.0)"
e2 <- "(+0.9)"
e3 <- "(+0.8)"
ploc <- -3.32
vloc <- -3.42

abline(v=fp, lty=2, lwd=2)
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

text(p1,-3.21, "PvdA", cex=cexp, font=2) 
text(p1,-3.31, e1, cex=cexp, font=2) 
axis(side=1, at=p1, labels="", tck=.1, lty=1, lwd=3)

text(16,ploc, "VVD", cex=cexp, font=2) 
text(16,vloc, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.02, lty=1, lwd=3)

text(-10,ploc, "D66", cex=cexp, font=2) 
text(-10,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)

### VVD
ylim <- c(.4,2.5)  # y-axis range

par(fig=c(.5,1,0,0.5), new=TRUE, mar=c(3.25,1.5,1.5,1))
plot(b$v, b$vvd, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$vvd, lty=1)
mtext("VVD's Left-Right Position", 1, line = 2, cex=cexp)

fp <- 15.12 # focal party's position
p1 <- 4.26
p2 <- -2.59 
p3 <- -8.24
e1 <- "(-2.0)"
e2 <- "(-2.2)"
e3 <- "(+0.8)"
ploc <- .6
vloc <- .47

abline(v=fp, lty=2, lwd=2)
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

text(8,ploc, "PvdA", cex=cexp, font=2) 
text(8,vloc, e1, cex=cexp, font=2) 
axis(side=1, at=4.26, labels="", tck=.02, lty=1, lwd=3)

text(p2,.79, "CDA", cex=cexp, font=2) 
text(p2,.65, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.1, lty=1, lwd=3)

text(-14,ploc, "D66", cex=cexp, font=2) 
text(-14,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)

dev.off()

################################################################################
### Ideological landscape of Ireland 1981 and Netherlands 1982
### Figure 5
################################################################################
pdf(file="figure5.pdf",fonts="serif")

xlat <- c(-50,0,50)
xlab <- c("Far Left","0","Far Right")
ylat <- c(-6, -4, -2, 0, 2, 4, 6)
ylab <- c("-6","-4","-2","0","2","4","6")
ylat2 <- c(-5, 0, 5)
ylab2 <- c("-5","0","5")

cexp <- .9
xlim <- c(-50,50)    # x-axis range
ylim <- c(-6,6)  # y-axis range
ylim2 <- c(-10,6)  # y-axis range

B <- matrix(NA,11,ncol=2)         

v <- -5
y <- -5
for(i in 1:11){
  B[i,1] <- v
  B[i,2] <- y
  v <- (v + 1)
  y <- (y + 1) 
}

par(fig=c(0,1,0.55,1), mar=c(4,4,2,1.5))

plot(B[,1], B[,2], xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
abline(h=0, lty=1, lwd=1.5)

segments(-8.7, 0, x1 = -8.7, y1 = -1.74, lwd=2)
segments(-1.4, 0, x1 = -1.4, y1 = -5.37, lwd=2)
segments(7.4, 0, x1 = 7.4, y1 = 5.97, lwd=2)

text(-16,-2, "Labour", cex=cexp) 
text(-11, -5, "Fianna Fail", cex=cexp)
text(17, 5, "Fine Gael", cex=cexp)

points(-8.7, y = -1.74, type = "p", pch=21, cex=2)
points(-1.4, y = -5.37, type = "p", pch=18, col="black", cex=2)
points(7.4, y = 5.97, type = "p", pch=21, cex=2)

axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)
mtext("Vote Change", 2, line = 2, cex=cexp)
mtext("Ireland 1981: Growth = -1.01%", 3, line = 0.5, las=0, font=2)
axis(2,labels=ylab,at=ylat)

### Netherlands 1982
par(fig=c(0,1,0.1,.55), mar=c(4,4,2,1.5), new=TRUE)

plot(B[,1], B[,2], xlim=xlim, ylim=ylim2, ann=F, type="n", xaxt="n", yaxt="n")
abline(h=0, lty=1, lwd=1.5)

segments(-20.7, 0, x1 = -20.7, y1 = 2.11, lwd=2)
segments(-12.6, 0, x1 = -12.6, y1 = -6.8, lwd=2)
segments(-11.7, 0, x1 = -11.7, y1 = -1.42, lwd=2)
segments(-8, 0, x1 = -8, y1 = -0.31, lwd=2)
segments(21, 0, x1 = 21, y1 = 5.76, lwd=2)

text(-28,2, "Labour", cex=cexp) 
text(-17, -6, "D66", cex=cexp)
text(2, -3, "Christian Democrats", cex=cexp)
text(0, 1, "Radicals", cex=cexp)
text(29, 5, "Liberals", cex=cexp)

points(-20.7, y = 2.11, type = "p", pch=18, col="grey", cex=2)
points(-12.6, y = -6.8, type = "p", pch=18, col="grey", cex=2)
points(-11.7, y = -1.42, type = "p", pch=18, col="black", cex=2)
points(-8, y = -0.31, type = "p", pch=21, cex=2)
points(21, y = 5.76, type = "p", pch=21, cex=2)


axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)
axis(2,labels=ylab2,at=ylat2)
mtext("Vote Change", 2, line = 2, cex=cexp)
mtext("Party's Left-Right Position", 1, line = 2, cex=cexp)
mtext("Netherlands 1982: Growth = -1.39%", 3, line = 0.5, las=0, font=2)

### Legend
par(fig=c(0,1,0,0.1), mar=c(.25,3,.25,1), new=TRUE)

yliml <- c(-0.5, 2.5)    # y-axis range
xliml <- c(0.5, 4.5)  # x-axis range

plot(0,0,type="n",xlim=xliml,ylim=yliml,axes=F,ann=F,cex=cexp)
leg.txt <- c("PM's Party", "Coalition Partner","Opposition Party")
pch_type <- c(18,18,21)
bg_type <- c("","","grey")
col_type <- c("black","grey")
legend(0.75, 2, leg.txt, pch = pch_type, bg = bg_type, col = col_type, cex=1, pt.cex=2, bty="n", ncol=3)

dev.off()


################################################################################
################################################################################
################################################################################
### Supporting Information
################################################################################
################################################################################
################################################################################

################################################################################
### Box-whisker plot of average distance between contiguous parties across country
################################################################################
distance = read.dta("Distance.dta", convert.underscore=TRUE) 
distancel = read.dta("Distance_low.dta", convert.underscore=TRUE)
distanceh = read.dta("Distance_high.dta", convert.underscore=TRUE)

pdf(file = "box.pdf", width = 6.5, height = 6.5)
g <- ggplot(distance) + aes(strccode, avg.dist) + geom_boxplot() + ylab("Average Distance") + xlab("Country") + coord_flip()
g <- g + scale_x_discrete(limits=c("Greece","Sweden","Germany","Iceland","Israel","Austria","France","Great Britain","Canada","Switzerland","Australia","New Zealand","Finland","Luxembourg","Ireland","Japan","Norway","Netherlands","Denmark","Portugal","Spain","Italy","Belgium"))
g
dev.off()

pdf(file = "box_clarity.pdf", width = 6.5, height = 6.5)
p <- ggplot(distance) + aes(strccode, avg.dist)
p <- p + geom_boxplot(data = distanceh, fill = "grey95") + annotate("text", label = "High Clarity", x = 21, y = 65, size = 6) + ylab("Average Distance") + xlab("Country") + coord_flip()
p <- p + geom_boxplot(data = distancel, fill = "grey60") + annotate("text", label = "Low Clarity", x = 1, y = 65, size = 6)
p <- p + scale_x_discrete(limits=c("Belgium","Italy","Portugal","Denmark","Netherlands","Norway","Japan","Ireland","Australia","Switzerland","Austria","Iceland","Germany","Sweden","Spain","Luxembourg","Finland","New Zealand","Canada","Great Britain","France","Israel","Greece"))
p
dev.off()

################################################################################
### Marginal effect of GDP across government dummy variable for 4 scenarios
### 2 x 2 table transformed into 4 figures
### SAMPLE: low clarity
### WEIGHTS MATRIX: closest neighbors, absolute distance
### X-axis range: -50 to 50
### Figure 2 (with confidence intervals)
################################################################################
b <- read.dta("growth_ci.dta") 

#pdf(file="C:/Users/williamslaro/Documents/Research/Projects/Spatial Economic Voting/Fall 2012/AJPS/R&R/Supporting Information/figure2_ci.pdf",fonts="serif")
pdf(file="figure2_ci.pdf",fonts="serif")

xlat <- c(-50,-25,0,25,50)
xlab <- c("-50","-25","0","25","50")

cexp <- .9
xlim <- c(-50,50)    # x-axis range
ylim <- c(.18,2)  # y-axis range

par(fig=c(0,1,0.025,1), mar=c(4,4,1.5,1.5))

plot(b$v, b$g_mn, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$g_mn, lty=1)
lines(b$v, b$g_lo_90, lty=2)
lines(b$v, b$g_hi_90, lty=2)
mtext("Marginal Effect of 1-S.D. Increase in GDP Growth", 2, line = 2, cex=cexp)
mtext("Prime Minister's Party's Left-Right Position", 1, line = 2, cex=cexp)

text(0,.24, "Opposition", cex=cexp, font=2) 
text(0,.19, "(-0.04%)", cex=cexp, font=2) 
axis(side=1,at=0,tck=.02, lty=1, lwd=3, labels="")
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

dev.off()



################################################################################
### Predicted vote share for an opposition party with varying rile; the government party is at 100 (middle)
### First obs is Party A, second obs is Party B
### SIMPLE VERSION: Party A's XB = 0 Party B's XB=-5
### Weights matrix: low clarity, neighbors, absolute distance
### X-axis range: 50-150
### 1 x 2 graph: Low clarity compared to high clarity
### High clarity is not just horizontal lines!
### Figure 3 (with confidence intervals)
################################################################################
hi <- read.dta("spat_ci_hi.dta") 
lo <- read.dta("spat_ci_low.dta") 

xlim <- c(-50,50)    # x-axis range
ylim <- c(-8,5)  # y-axis range
yla <- c("-8","-4","0","4")
yla2 <- c("","","","","")
xlat <- c(-50,-25,0,25,50)
xlab <- c("-50","-25","0","25","50")
cexp <- .9

pdf(file="figure3_ci.pdf",fonts="serif")

# High clarity case
par(fig=c(0,.55,0.15,1),mar=c(.25,5,.5,1))
plot(0, 0, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
lines(hi$v, hi$o_mn, lty=1)
lines(hi$v, hi$o_lo_90, lty=2)
lines(hi$v, hi$o_hi_90, lty=2)
lines(hi$v, hi$g_mn, lty=1)
lines(hi$v, hi$g_lo_90, lty=2)
lines(hi$v, hi$g_hi_90, lty=2)
axis(1,cex.axis=cexp, mgp=c(3,.4,0), labels=xlab,at=xlat)
axis(2,labels=yla,at=yla,las=1,cex.axis=cexp)
mtext("Party A's Left-Right Position", 1, line = 1.5, las=0)
mtext("Predicted Vote Change", 2, line = 2.5)
mtext(expression(paste("High Clarity (",rho,"= -.004)")), 3, line = -1.5, las=0)
text(0,-8, "Party B", cex=cexp, font=2) 
axis(side=1,at=0,tck=.02, lty=1, lwd=3, cex=cexp,labels=c(""))

# Low clarity case
par(fig=c(0.55,1,0.15,1),mar=c(.25,1,.5,1),new=TRUE)
plot(0, 0, xlim=xlim, ylim=ylim, cex=cexp, ann=F, type="n",axes="F")
lines(lo$v, lo$o_mn, lty=1)
lines(lo$v, lo$o_lo_90, lty=2)
lines(lo$v, lo$o_hi_90, lty=2)
lines(lo$v, lo$g_mn, lty=1)
lines(lo$v, lo$g_lo_90, lty=2)
lines(lo$v, lo$g_hi_90, lty=2)
axis(1,cex.axis=cexp, mgp=c(3,.4,0), labels=xlab,at=xlat)
axis(2,labels=yla,at=yla,las=1,cex.axis=cexp)
mtext("Party A's Left-Right Position", 1, line = 1.5, las=0)
mtext(expression(paste("Low Clarity (",rho,"= -.012)")), 3, line = -1.5, las=0)
text(0,-8, "Party B", cex=cexp, font=2) 
axis(side=1,at=0,tck=.02, lty=1, lwd=3, cex=cexp,labels=c(""))
  
# Legend
par(fig=c(0,1,0,.15), new=TRUE, mar=c(1,4,1,1))
plot(0,0,xlim=xlim,ylim=ylim,cex=cexp,type="n",axes=F,ann=F)
leg.txt <- c(expression(paste("Party A: X",beta,"= 0%")), expression(paste("Party B: X",beta,"= -5%")))
lty.type <- c(1,2)
legend(-35, -1.5, leg.txt, lty=lty.type, cex=1, ncol=2, lwd=1, bty="n")

dev.off()



################################################################################
### Predicted vote change for actual scenarios
### Netherlands 1994
### 2 x 2 table
### SAMPLE: low clarity only
### WEIGHTS MATRIX: closest neighbors, absolute distance
### X-axis range: 50-150
### Figure 4 (with confidence intervals)
################################################################################
b <- read.csv("netherlands_1994_ci.csv", sep=",", header=TRUE) 

summary(b$pvda)
summary(b$d66)
summary(b$cda)
summary(b$vvd)

cexp <- .7
xlat <- c(-50,-25,0,25,50)
xlab <- c("-50","-25","0","25","50")

pdf(file="figure4_ci.pdf",fonts="serif")

### PvdA
xlim <- c(-50,50)    # x-axis range
ylim <- c(-3.5,-1.5)  # y-axis range

par(fig=c(0,.5,0.55,1),mar=c(.25,4,.5,1))
plot(b$v, b$pvda, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$pvda, lty=1)
lines(b$v, b$pvda_lo_90, lty=2)
lines(b$v, b$pvda_hi_90, lty=2)
mtext("Predicted Vote Change", 2, line = 2, cex=cexp)
mtext("PvdA's Left-Right Position", 1, line = 2, cex=cexp)

fp <- 4.26 # focal party's position
#p1 <- 91.76
p1 <- -10
p2 <- -2.59 
p3 <- 15.12
e1 <- "(+0.8)"
e2 <- "(-2.2)"
e3 <- "(+0.9)"
ploc <- -3.36
vloc <- -3.45

axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

abline(v=fp, lty=2, lwd=2)
text(-13,-3.25, "D'66", cex=cexp, font=2) 
text(-13,-3.34, e1, cex=cexp, font=2) 
axis(side=1, at=p1, labels="", tck=.1, lty=1, lwd=3)

text(-1,ploc, "CDA", cex=cexp, font=2) 
text(-1,vloc, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.02, lty=1, lwd=3)

text(p3,ploc, "VVD", cex=cexp, font=2) 
text(p3,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)


### D'66
ylim <- c(0.25,3.25)  # y-axis range

par(fig=c(.5,1,0.55,1), new=TRUE, mar=c(.25,1.5,.5,1))
plot(b$v, b$d66, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$d66, lty=1)
lines(b$v, b$d66_lo_90, lty=2)
lines(b$v, b$d66_hi_90, lty=2)
mtext("D'66's Left-Right Position", 1, line = 2, cex=cexp)

fp <- -8.24 # focal party's position
p1 <- 4.26
p2 <- -2.59 
p3 <- 15.12
e1 <- "(-2.0)"
e2 <- "(-2.2)"
e3 <- "(+0.9)"
ploc <- .44
vloc <- .32

abline(v=fp, lty=2, lwd=2)
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

text(p1,.65, "PvdA", cex=cexp, font=2) 
text(p1,.53, e1, cex=cexp, font=2) 
axis(side=1, at=p1, labels="", tck=.1, lty=1, lwd=3)

text(-3.8,ploc, "CDA", cex=cexp, font=2) 
text(-3.6,vloc, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.02, lty=1, lwd=3)

text(p3,ploc, "VVD", cex=cexp, font=2) 
text(p3,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)


###  CDA
ylim <- c(-4,-2)  # y-axis range

par(fig=c(0,.5,0,0.5), new=TRUE, mar=c(3.25,4,1.5,1))
plot(b$v, b$cda, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$cda, lty=1)
lines(b$v, b$cda_lo_90, lty=2)
lines(b$v, b$cda_hi_90, lty=2)

mtext("Predicted Vote Change", 2, line = 2, cex=cexp)
mtext("CDA's Left-Right Position", 1, line = 2, cex=cexp)

fp <- -2.59 # focal party's position
p1 <- 4.26
p2 <- 15.12 
p3 <- -8.24
e1 <- "(-2.0)"
e2 <- "(+0.9)"
e3 <- "(+0.8)"
ploc <- -3.82
vloc <- -3.92

abline(v=fp, lty=2, lwd=2)
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

text(p1,-3.71, "PvdA", cex=cexp, font=2) 
text(p1,-3.81, e1, cex=cexp, font=2) 
axis(side=1, at=p1, labels="", tck=.1, lty=1, lwd=3)

text(16,ploc, "VVD", cex=cexp, font=2) 
text(16,vloc, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.02, lty=1, lwd=3)

text(-10,ploc, "D66", cex=cexp, font=2) 
text(-10,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)

### VVD
ylim <- c(.4,3)  # y-axis range

par(fig=c(.5,1,0,0.5), new=TRUE, mar=c(3.25,1.5,1.5,1))
plot(b$v, b$vvd, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$v, b$vvd, lty=1)
lines(b$v, b$vvd_lo_90, lty=2)
lines(b$v, b$vvd_hi_90, lty=2)
mtext("VVD's Left-Right Position", 1, line = 2, cex=cexp)

fp <- 15.12 # focal party's position
p1 <- 4.26
p2 <- -2.59 
p3 <- -8.24
e1 <- "(-2.0)"
e2 <- "(-2.2)"
e3 <- "(+0.8)"
ploc <- .6
vloc <- .47

abline(v=fp, lty=2, lwd=2)
axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)

text(8,ploc, "PvdA", cex=cexp, font=2) 
text(8,vloc, e1, cex=cexp, font=2) 
axis(side=1, at=4.26, labels="", tck=.02, lty=1, lwd=3)

text(p2,.79, "CDA", cex=cexp, font=2) 
text(p2,.65, e2, cex=cexp, font=2) 
axis(side=1, at=p2, labels="", tck=.1, lty=1, lwd=3)

text(-14,ploc, "D66", cex=cexp, font=2) 
text(-14,vloc, e3, cex=cexp, font=2) 
axis(side=1, at=p3, labels="", tck=.02, lty=1, lwd=3)

dev.off()











