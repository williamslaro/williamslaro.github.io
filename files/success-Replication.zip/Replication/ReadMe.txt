This zip file contains the material needed to replicate the findings from the November 2011 Comparative Political Studies article, "Unsuccessful Success?  Failed No-Confidence Motions, Competence Signals, and Electoral Support".

The Stata data set is called "Unsuccessful Success.dta" and includes the sample parties and all the necessary variables.

The replication file is a Stata do file that contains all the commands to replicate the empirical findings contained in the manuscript: "Electoral Success Replication.do".

Any questions, email the author at laron.williams@ttu.edu

