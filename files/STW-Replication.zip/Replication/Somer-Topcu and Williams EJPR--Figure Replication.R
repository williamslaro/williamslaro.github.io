##=============================================================================#
## Code to replicate the figure in Somer-Topcu and Williams' "Opposition Party Policy Shifts in Response to No-Confidence Motions", EJPR.
## 
## Created : 10-25-13
## NOTE: this uses the "Marginal Effects.dta" file that is created in the Stata replication file. 
##
##=============================================================================#
#rm(list=ls())
#require(lattice)
#require(MASS)
#require(ggplot2)

library(foreign)

# Set up the working directory!
#setwd("C:")

##==================================================#
## Figure 1: Marginal effect of a no-confidence motion across economic growth (main model)
##==================================================#
b <- read.dta("Marginal Effects.dta") 

xlat <- c(-4,-2,0,2,4)
xlab <- c("-4","-2","0","2","4")

cexp <- 1
xlim <- c(-4.5,4.5)    # x-axis range
ylim <- c(-10,5)  # y-axis range

par(fig=c(0,1,0.025,1), mar=c(4,4,1.5,1.5))

plot(b$Z, b$ME_X, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")
lines(b$Z, b$ME_X, lty=1)
lines(b$Z, b$LO_X, lty=2)
lines(b$Z, b$HI_X, lty=2)
mtext("Marginal Effect of an NCM", 2, line = 2, cex=cexp)
mtext("GDP Growth", 1, line = 2, cex=cexp)
abline(h=0, lty=1, lwd=1.5)

axis(1,mgp=c(3,.4,0), labels=xlab,at=xlat)
