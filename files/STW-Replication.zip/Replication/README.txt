This zipped folder contains all the files necessary to replicate all the empirical results and figures contained in the Somer-Topcu and Williams "Opposition Party Policy Shifts in Response to No-Confidence Motions", European Journal of Political Research.

The folder contains the following files:

1) "Somer-Topcu and Williams EJPR--Supplemental Materials.pdf": contains the sample details and all the additional robustness checks mentioned in the manuscript.

2) "Somer-Topcu and Williams EJPR--Replication.do": Stata do file that uses the data set ("Somer-Topcu and Williams EJPR--Replication.dta") to replicate all the empirical results.  You will need to update the current working directory to be the folder containing these files!

3) "Somer-Topcu and Williams EJPR--Replication.smcl": Stata log file that shows exact replication of all of the empirical results.

4) "Somer-Topcu and Williams EJPR--Figure Replication.R": R file that contains the code necessary to replicate Figure 1.  Note that you must create the "Marginal Effects.dta" file in the Stata replication file before trying to create this figure!

Please feel free to contact me if you have any questions: williamslaro@missouri.edu
