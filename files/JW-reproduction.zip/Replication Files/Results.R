######################################################################################
# REPLICATION CODE:
# AUTHORS: Sebastian Juhl and Laron K. Williams
# ARTICLE: "Learning at Home and Abroad: How Competition Conditions the
#           Diffusion of Party Strategies"
# JOURNAL: British Journal of Political Science
######################################################################################

# NOTE:
# This code produces all figures and tables reported in the main
# article and stores the results in the subfolder "Output" which will
# be created unless it exists already.

# set working directory
setwd(YOUR_DIRECTORY)

# clear working environment
rm(list=ls(all=T))

# create empty output folder
ifelse(!dir.exists(file.path(paste0(getwd(),"/Output")))
       ,dir.create(file.path(paste0(getwd(),"/Output"))), FALSE)

setwd("/Users/sebastianjuhl/Dropbox/Issue Competition/BJPolS Submission/Final Submission/Replication Files")

### PACKAGES
library(MASS)
library(dplyr)
library(ggplot2)

### LOAD DATASETS
# load data
load("./Data/Juhl_Williams_Data.RData")
# load connectivity matrices
load("./Data/Matrices.RData")


# define spatial lags
W.f.win <- W.f.win[complete,complete]
W.f.lose <- W.f.lose[complete,complete]
W.d.win <- W.d.win[complete,complete]
W.d.lose <- W.d.lose[complete,complete]
data$f.bloc.win <- W.f.win %*% data$issue
data$f.bloc.lose <- W.f.lose %*% data$issue
data$d.bloc.win.lag <- W.d.win %*% data$issue
data$d.bloc.lose.lag <- W.d.lose %*% data$issue


# sum of links
s.f.bloc.win <- apply(W.f.win,1,sum)
s.f.bloc.lose <- apply(W.f.lose,1,sum)
s.d.bloc.win.lag <- apply(W.d.win,1,sum)
s.d.bloc.lose.lag <- apply(W.d.lose,1,sum)

# average number of neighbors
avg.f.bloc.win <- mean(apply(W.f.win,1,sum))
avg.f.bloc.lose <- mean(apply(W.f.lose,1,sum))
avg.d.bloc.win <- mean(apply(W.d.win,1,sum))
avg.d.bloc.lose <- mean(apply(W.d.lose,1,sum))


### Table 2: Descriptive Statistics
nams <- c("y","DV_t-1","W^Fwy","W^Fly","W^Dwy","W^Dly"
          ,"VSGreen_t-1","AvgGreen_n-1","GDP_n-1","Incumbent_t"
          ,"Incumbent_DVt-1","VS_t-1")
pos <- c(1:2,10:13,3,9,5:6,8,7)
Mean <- round(apply(data[,pos],2,mean),3)
SD <- round(apply(data[,pos],2,sd),3)
Min <- round(apply(data[,pos],2,min),3)
Max <- round(apply(data[,pos],2,max),3)
tab2 <- cbind(Mean,SD,Min,Max)
rownames(tab2) <- nams
write.csv2(tab2,file="./Output/Table_2.csv")


# MODELS
nams <- c("Constant","","DV_t-1","","W^Fwy","","W^Fly","","W^Dwy",""
          ,"W^Dly","","VSGreen_t-1","","VSGreen_t-1^2","","AvgGreen_n-1",""
          ,"GDP_n-1","","Incumbent_t","","Incumbent_DVt-1","","VS_t-1","")
coefs <- matrix("-",nrow=13,ncol=3)
ses <- matrix("",nrow=13,ncol=3)
m1 <- glm(issue ~ issue.lag
          + f.bloc.win + f.bloc.lose
          + vsgreen.lag
          + vsgreen.lag2
          + globalgreen.lag
          + gdp.lag
          + incumbent
          + incumbent.emphasis.lag
          + prevvote
          + factor(cmp$party)
          + factor(cmp$year)
          ,data=data
          ,family=quasibinomial("logit"))
coef1 <- round(coef(m1),3)[1:11]
se1 <- round(summary(m1)$coefficients[,"Std. Error"],3)[1:11]
pos1 <- c(1:4,7:13)
coefs[pos1,1] <- coef1
ses[pos1,1] <- se1

m2 <- glm(issue ~ issue.lag
          + d.bloc.win.lag + d.bloc.lose.lag
          + vsgreen.lag
          + vsgreen.lag2
          + globalgreen.lag
          + gdp.lag
          + incumbent
          + incumbent.emphasis.lag
          + prevvote
          + factor(cmp$party)
          + factor(cmp$year)
          ,data=data
          ,family=quasibinomial("logit"))
coef2 <- round(coef(m2),3)[1:11]
se2 <- round(summary(m2)$coefficients[,"Std. Error"],3)[1:11]
pos2 <- c(1:2,5:13)
coefs[pos2,2] <- coef2
ses[pos2,2] <- se2

m3 <- glm(issue ~ issue.lag
          + f.bloc.win + f.bloc.lose
          + d.bloc.win.lag + d.bloc.lose.lag
          + vsgreen.lag
          + vsgreen.lag2
          + globalgreen.lag
          + gdp.lag
          + incumbent
          + incumbent.emphasis.lag
          + prevvote
          + factor(cmp$party)
          + factor(cmp$year)
          ,data=data
          ,family=quasibinomial("logit"))
coef3 <- round(coef(m3),3)[1:13]
se3 <- round(summary(m3)$coefficients[,"Std. Error"],3)[1:13]
pos3 <- 1:13
coefs[pos3,3] <- coef3
ses[pos3,3] <- se3

tmp <- NULL
for(i in 1:13){
  tmp <- rbind(tmp,coefs[i,],ses[i,])
}
rownames(tmp) <- nams
colnames(tmp) <- c("Model_1","Model_2","Model_3")

# phi
phi <- c(round(summary(m1)$dispersion,4)
         ,round(summary(m2)$dispersion,4)
         ,round(summary(m3)$dispersion,4))
# Observations
Observations <- c(length(m1$residuals),length(m2$residuals),length(m3$residuals))
# RMSE
RMSE <- c(round(sqrt(mean((m1$fitted.values - m1$y)^2)),4)
          ,round(sqrt(mean((m2$fitted.values - m2$y)^2)),4)
          ,round(sqrt(mean((m3$fitted.values - m3$y)^2)),4))

tab3 <- rbind(tmp,phi,Observations,RMSE)

# F-test of joint null hypothesis (H2)
anova(m1,m3,test="F")

# APPENDIX
# conditional spatial dependence
m5 <- glm(issue ~ issue.lag
          + f.bloc.win + f.bloc.lose
          + d.bloc.win.lag + d.bloc.lose.lag
          + I(vsgreen.lag*f.bloc.win) + I(vsgreen.lag*f.bloc.lose)
          + vsgreen.lag
          + vsgreen.lag2
          + globalgreen.lag
          + gdp.lag
          + incumbent
          + incumbent.emphasis.lag
          + prevvote
          + factor(cmp$party)
          + factor(cmp$year)
          ,data=data
          ,family=quasibinomial("logit"))
summary(m5)
round(coef(m5),3)[1:15]
round(summary(m5)$coefficients[1:15,"Std. Error"],3)
# RMSE
round(sqrt(mean((m5$fitted.values - m5$y)^2)),4)



# Riding the Wave: all domestic parties
# define spatial lags
W.d.all <- W.d.all[complete,complete]
data$d.all.lag <- W.d.all %*% data$issue

# average number of neighbors
mean(apply(W.d.all,1,sum))

m6 <- glm(issue ~ issue.lag
          + f.bloc.win + f.bloc.lose
          + d.all.lag
          + vsgreen.lag
          + vsgreen.lag2
          + globalgreen.lag
          + gdp.lag
          + incumbent
          + incumbent.emphasis.lag
          + prevvote
          + factor(cmp$party)
          + factor(cmp$year)
          ,data=data
          ,family=quasibinomial("logit"))
summary(m6)
round(coef(m6),3)[1:12]
round(summary(m6)$coefficients[1:12,"Std. Error"],3)
# RMSE
round(sqrt(mean((m6$fitted.values - m6$y)^2)),4)

m7 <- glm(issue ~ issue.lag
          + f.bloc.win + f.bloc.lose
          + d.bloc.win.lag + d.bloc.lose.lag
          + d.all.lag
          + vsgreen.lag
          + vsgreen.lag2
          + globalgreen.lag
          + gdp.lag
          + incumbent
          + incumbent.emphasis.lag
          + prevvote
          + factor(cmp$party)
          + factor(cmp$year)
          ,data=data
          ,family=quasibinomial("logit"))
summary(m7)
round(coef(m7),3)[1:14]
round(summary(m7)$coefficients[1:14,"Std. Error"],3)
# RMSE
round(sqrt(mean((m7$fitted.values - m7$y)^2)),4)



### Differences Winners vs losers (Model 3)
diff <- matrix(NA,nrow=2,ncol=3)
# Foreign
f.vcov <- vcov(m3)
f.vcov <- f.vcov[rownames(f.vcov)=="f.bloc.win" | rownames(f.vcov)=="f.bloc.lose",colnames(f.vcov)=="f.bloc.win" | colnames(f.vcov)=="f.bloc.lose"]
f.coefs <- m3$coefficients[names(m3$coefficients)=="f.bloc.win" | names(m3$coefficients)=="f.bloc.lose"]
f.est <- f.coefs[1]-f.coefs[2]
f.var <- f.vcov[1,1] + f.vcov[2,2] -2*f.vcov[1,2]
diff[1,3] <- f.est+qnorm(.05/2,lower=F)*sqrt(f.var) # two-sided test?
diff[1,2] <- f.est
diff[1,1] <- f.est-qnorm(.05/2,lower=F)*sqrt(f.var) # two-sided test?
f.t <- f.est/sqrt(f.var)
2*pt(-abs(f.t),df=nrow(data)-2)
qt(.05,df=nrow(data)-2,lower=F)
# Domestic
d.vcov <- vcov(m3)
d.vcov <- d.vcov[rownames(d.vcov)=="d.bloc.win.lag" | rownames(d.vcov)=="d.bloc.lose.lag",colnames(d.vcov)=="d.bloc.win.lag" | colnames(d.vcov)=="d.bloc.lose.lag"]
d.coefs <- m3$coefficients[names(m3$coefficients)=="d.bloc.win.lag" | names(m3$coefficients)=="d.bloc.lose.lag"]
d.est <- d.coefs[1]-d.coefs[2]
d.var <- d.vcov[1,1] + d.vcov[2,2] -2*d.vcov[1,2]
diff[2,3] <- d.est+qnorm(.05/2,lower=F)*sqrt(d.var)
diff[2,2] <- d.est
diff[2,1] <- d.est-qnorm(.05/2,lower=F)*sqrt(d.var)
d.t <- d.est/sqrt(d.var)
2*pt(d.t,df=nrow(data)-2,lower=F)
2*pt(-abs(d.t),df=nrow(data)-2)

round(diff,3)


# minimum of quadratic term
f <- expression(vsgreen.lag*x + vsgreen.lag2*x^2)
D(f,"x")
fun <- function(x) coef(m3)["vsgreen.lag"] + coef(m3)["vsgreen.lag2"] * (2*x)
round(uniroot(fun,interval=c(min(data$vsgreen.lag),max(data$vsgreen.lag)))$root,3)
# Test for U-shape (Lind/ Mehlum 2010)
vcov <- vcov(m3)
vcov <- vcov[rownames(vcov)=="vsgreen.lag" | rownames(vcov)=="vsgreen.lag2",colnames(vcov)=="vsgreen.lag" | colnames(vcov)=="vsgreen.lag2"]
coefs <- m3$coefficients[names(m3$coefficients)=="vsgreen.lag" | names(m3$coefficients)=="vsgreen.lag2"]
round(-coefs[1]/(2*coefs[2]),3) # minimum
xl <- min(data$vsgreen.lag,na.rm=T)
xh <- max(data$vsgreen.lag,na.rm=T)
# slopes and SEs
# xl
coefs[1] + 2*coefs[2] * xl
sqrt((vcov[1,1] + 4*xl*vcov[1,2] + 4*xl^2*vcov[2,2]))
#xh
coefs[1] + 2*coefs[2] * xh
sqrt((vcov[1,1] + 4*xh*vcov[1,2] + 4*xh^2*vcov[2,2]))
# test statistic
(tl <- (coefs[1] + 2*coefs[2]*xl)/(sqrt(vcov[1,1]+4*xl^2*vcov[2,2]+4*xl*vcov[1,2])))
(th <- (coefs[1] + 2*coefs[2]*xh)/(sqrt(vcov[1,1]+4*xh^2*vcov[2,2]+4*xh*vcov[1,2])))
# p value
t_sac <- min(abs(tl),abs(th))
2*pt(t_sac,(nrow(data)-1),lower=F)



#library(stargazer)
#stargazer(m1,m2,m3)


##############
# SIMULATION
##############
set.seed(123)
# Extract information for Simulations
coefs <- m3$coefficients[1:13]
vcov <- vcov(m3)[1:13,1:13]
nsim <- 10000
sims <- mvrnorm(nsim,mu=coefs,Sigma=vcov)
# Things for spatial AMEs
ame.sim <- matrix(NA,nrow=nsim,ncol=4)
colnames(ame.sim) <- c("f.bloc.win","f.bloc.lose","d.bloc.win.lag","d.bloc.lose.lag")
# Things for Marginal Effects of VSGreen
greenvote <- seq(from=0, to=17,by=.1)
gvote <- matrix(NA,nrow=nsim,ncol=length(greenvote))
# Things for Spillover Effects
j.xb_0 <- j.odds_0 <- j.xb_5 <- j.odds_5 <- j.prob_0 <- j.prob_5 <- NULL # js
j.prob_0 <- j.prob_5
i.xb_0 <- i.odds_0 <- i.xb_5 <- i.odds_5 <- i.prob_0 <- i.prob_5 <- NULL # is
for(i in 1:nsim){
  # AME of spatial coefficients
  scenario <- cbind(1,data$issue.lag
                    ,data$f.bloc.win
                    ,data$f.bloc.lose
                    ,data$d.bloc.win.lag
                    ,data$d.bloc.lose.lag
                    ,data$vsgreen.lag,data$vsgreen.lag2
                    ,data$globalgreen.lag
                    ,data$gdp.lag,data$incumbent
                    ,data$incumbent.emphasis.lag
                    ,data$prevvote)
  # xb
  xb <- scenario %*% sims[i,]
  # get probabilities
  p <- exp(xb)/(1+exp(xb))
  
  ame.sim[i,"f.bloc.win"] <- 1/nrow(data) * sum((sims[i,"f.bloc.win"]*s.f.bloc.win)*p*(1-p))
  ame.sim[i,"f.bloc.lose"] <- 1/nrow(data) * sum((sims[i,"f.bloc.lose"]*s.f.bloc.lose)*p*(1-p))
  ame.sim[i,"d.bloc.win.lag"] <- 1/nrow(data) * sum((sims[i,"d.bloc.win.lag"]*s.d.bloc.win.lag)*p*(1-p))
  ame.sim[i,"d.bloc.lose.lag"] <- 1/nrow(data) * sum((sims[i,"d.bloc.lose.lag"]*s.d.bloc.lose.lag)*p*(1-p))
  
  # Marginal Effect of Green Vote Share
  #gvote[i,] <- sims[i,"vsgreen.lag"] + 2*sims[i,"vsgreen.lag2"] * greenvote
  for(g in 1:ncol(gvote)){
    gvote[i,g] <- 1/nrow(data) * sum((sims[i,"vsgreen.lag"] + 2*sims[i,"vsgreen.lag2"] * greenvote[g]) *p*(1-p))
  }
}


# Average Marginal Effects
ame <- matrix(NA,nrow=4,ncol=3)
colnames(ame) <- c("lowerCI","Estimate","upperCI")
rownames(ame) <- c("f.bloc.win","f.bloc.lose","d.bloc.win.lag","d.bloc.lose.lag")
ame[,"Estimate"] <- apply(ame.sim,2,mean)
ame[,"lowerCI"] <- apply(ame.sim,2,quantile, probs=.025)
ame[,"upperCI"] <- apply(ame.sim,2,quantile, probs=.975)

mean(data$issue)
mean(data$issue) - sd(data$issue)
mean(data$issue) + sd(data$issue)

ch <- (mean(data$issue) + sd(data$issue)) - (mean(data$issue) - sd(data$issue))
ch <- ch*median(s.f.bloc.win)
ame["f.bloc.win","Estimate"]*ch
ame["f.bloc.win","lowerCI"]*ch
ame["f.bloc.win","upperCI"]*ch

round(ame,3)



###################
# Figures
###################

# Average Marginal Effects (AME) Plot
tikz(paste0(getwd(),"/BJPolS Submission/1. Revision/Revised Manuscript/ame.tex"),width=5,height=3)
par(mar=c(3.5,5,0.1,2))
plot(x=ame[,"Estimate"],y=c(4,3,2,1),ylim=c(0,5),xlim=c(-.45,.85),pch=4,axes=F,ann=F)
lines(y=c(4,4),x=c(ame["f.bloc.win","lowerCI"],ame["f.bloc.win","upperCI"]))
lines(y=c(3,3),x=c(ame["f.bloc.lose","lowerCI"],ame["f.bloc.lose","upperCI"]))
lines(y=c(2,2),x=c(ame["d.bloc.win.lag","lowerCI"],ame["d.bloc.win.lag","upperCI"]))
lines(y=c(1,1),x=c(ame["d.bloc.lose.lag","lowerCI"],ame["d.bloc.lose.lag","upperCI"]))
text(x=c(ame[1,2],ame[2,2]-.005,ame[3,2]+.07,ame[4,2]-.05),y=c(4,3,2,1),labels=round(ame[,2],3),pos=3,cex=.7)
abline(v=0,lty=2)
axis(1)
#axis(1,c(-1,-.2,-.1,0,.1,.2,.3,.4,.5,1),labels=c("","-0.2","-0.1","0","0.1","0.2","0.3","0.4","0.5",""))
axis(2,c(-1,1,2,3,4,6),labels=c("","$\\theta_4{\\bf W}^{D_L}{\\bf y}$","$\\theta_3{\\bf W}^{D_W}{\\bf y}$"
                                ,"$\\theta_2{\\bf W}^{F_L}{\\bf y}$","$\\theta_1{\\bf W}^{F_W}{\\bf y}$","")
     ,las=1)
mtext("Effect Size",1,line=2.4)
box("plot",lwd=2)
dev.off()


# Marginal Effects Plot Greenvote
est <- apply(gvote,2,mean)
low <- apply(gvote,2,quantile,probs=.025)
up <- apply(gvote,2,quantile,probs=.975)
tikz(paste0(getwd(),"/BJPolS Submission/1. Revision/Supplementary Materials/greenvote.tex"),width=5,height=3)
par(mar=c(3.5,4.9,0.1,2))
plot(x=greenvote,y=est,ylim=c(-.035,.035),xlim=c(0.5,15),type="l",lwd=2.5,axes=F,ann=F)
lines(greenvote,low)
lines(greenvote,up)
abline(h=0,lty=2)
rug(data$vsgreen.lag,col="gray70")
axis(1,c(-10,0,5,10,15,20),labels=c("","0","5","10","15",""),cex.axis=.9)
axis(2,las=1,cex.axis=.9)
mtext("Green Vote Share at t-1",1,line=2.4)
mtext("Marginal Effect",2,line=3)
box("plot",lwd=2)
dev.off()




##############################
# Simulation Study
##############################
# Green Party in Sweden double its VS
# How do conservative parties (parfam==60) react?

cmp$country[cmp$countryname=="Sweden"] # id = 11
unique(cmp$date[cmp$countryname=="Sweden"]) # election in 2010
unique(data$vsgreen.lag[cmp$countryname=="Sweden" & cmp$year==2010]) # from 5.244% to 15.244%
nrow(data[cmp$countryname=="Sweden"&cmp$year==2010&cmp$parfam==60,])
change[cmp$countryname=="Sweden"&cmp$year==2010] # only conservatives increased vote share!
cmp$partyname[cmp$countryname=="Sweden"&cmp$year==2010&cmp$parfam==60] # Moderate Party
change[cmp$countryname=="Sweden"&cmp$year==2010&cmp$parfam==60] # conservatives increased VS by 3.83%
data$issue[cmp$countryname=="Sweden"&cmp$year==2010&cmp$parfam==60]

# define selector
sel <- cmp$countryname=="Sweden"&cmp$year==2010&cmp$parfam==60
sum(sel)


set.seed(123)
# Extract information for Simulations
coefs <- m3$coefficients#[1:11]
vcov <- vcov(m3)#[1:11,1:11]
nsim <- 10000
sims <- mvrnorm(nsim,mu=coefs[!is.na(coefs)],Sigma=vcov[!is.na(coefs),!is.na(coefs)])

fes <- rep(0,sum(grepl("^factor\\(cmp\\$",names(coefs))))
fes[names(coefs[grepl("^factor\\(cmp\\$",names(coefs))])==paste0("factor(cmp$party)",cmp$party[sel])] <- 1
fes[names(coefs[grepl("^factor\\(cmp\\$",names(coefs))])==paste0("factor(cmp$year)",cmp$year[sel])] <- 1



# define true scenario (conservative party in Sweden 2010)
truesweden2010 <- c(1,data$issue.lag[sel]
                           ,data$f.bloc.win[sel]
                           ,data$f.bloc.lose[sel]
                           ,data$d.bloc.win.lag[sel]
                           ,data$d.bloc.lose.lag[sel]
                           ,data$vsgreen.lag[sel]
                           ,data$vsgreen.lag[sel]^2
                           ,data$globalgreen.lag[sel]
                           ,data$gdp.lag[sel]
                           ,data$incumbent[sel] # gov party
                           ,data$incumbent.emphasis.lag[sel]
                           ,data$prevvote[sel]
                           ,fes)

truesweden2010 <- truesweden2010[!is.na(coefs)]

# define fabricated y (issue emphasis of conservative party 2010 in Sweden if vsgreen.lag doubles)
fakesweden2010 <- c(1,data$issue.lag[sel]
                        ,data$f.bloc.win[sel]
                        ,data$f.bloc.lose[sel]
                        ,data$d.bloc.win.lag[sel]
                        ,data$d.bloc.lose.lag[sel]
                        ,data$vsgreen.lag[sel] *2
                        ,(data$vsgreen.lag[sel] *2)^2
                        ,data$globalgreen.lag[sel]
                        ,data$gdp.lag[sel]
                        ,data$incumbent[sel] # gov party
                        ,data$incumbent.emphasis.lag[sel]
                        ,data$prevvote[sel]
                        ,fes)

fakesweden2010 <- fakesweden2010[!is.na(coefs)]
dim(sims)
length(truesweden2010)


prob_base <- prob_fake <- NULL
for(i in 1:nsim){
  # 1. predict true y (issue emphasis of conservative party 2010 in Sweden)
  # log odds ratios
  xb_base <- truesweden2010 %*% sims[i,]
  # get from log odds to probabilities
  odds_base <- exp(xb_base)
  prob_base[i] <- odds_base/(1+odds_base)
  
  # 2. predict fake y
  # log odds ratios
  xb_fake <- fakesweden2010 %*% sims[i,]
  # get from log odds to probabilities
  odds_fake <- exp(xb_fake)
  prob_fake[i] <- odds_fake/(1+odds_fake)
}


quantile(prob_base,probs=c(.025,.5,.975))*100
quantile(prob_fake,probs=c(.025,.5,.975))*100

quantile(apply(cbind(prob_fake,prob_base),1,function(x) x[1]-x[2]),probs=c(.025,.5,.975))*100

# How does this spread through Europe?
# define new dataset with fake issue emphasis
newdata <- data[cmp$date>201009 & cmp$parfam==60,]
newcmp <- cmp[cmp$date>201009 & cmp$parfam==60,]
length(unique(newcmp$country)) # 14 countries but 19 entries
# tkae the mean for more than one conservative party in system
# BUT: exclude elections in a polity that had already an election after 2010
# (Spain 201512, Estonia 201503, Latvia 201410)
newsel <- cmp$date>=201009 & cmp$parfam==60 & !c(cmp$countryname=="Spain" & cmp$date==201512) & !c(cmp$countryname=="Estonia" & cmp$date==201503) & !c(cmp$countryname=="Latvia" & cmp$date==201410) 
newdata <- data[newsel,]
newcmp <- cmp[newsel,]

newcmp$year

names(coefs)

newfes <- matrix(0,nrow=nrow(newdata),ncol=sum(grepl("^factor\\(cmp\\$",names(coefs))))
for(i in 1:nrow(newdata)){
  newfes[i,names(coefs[grepl("^factor\\(cmp\\$",names(coefs))])%in%paste0("factor(cmp$party)",newcmp$party[i])] <- 1
  newfes[i,names(coefs[grepl("^factor\\(cmp\\$",names(coefs))])%in%paste0("factor(cmp$year)",newcmp$year[i])] <- 1
}

newW.f.win <- W.f.win[newsel ,newsel]
newW.f.lose <- W.f.lose[newsel,newsel]
newW.d.win <- W.d.win[newsel,newsel]
newW.d.lose <- W.d.lose[newsel,newsel]
# Social Democratic parties with true input
truesocdemscenario <- cbind(1,newdata$issue.lag
                            ,newW.f.win %*% newdata$issue
                            ,newW.f.lose %*% newdata$issue
                            ,newW.d.win %*% newdata$issue
                            ,newW.d.lose %*% newdata$issue
                            ,newdata$vsgreen.lag
                            ,newdata$vsgreen.lag2
                            ,newdata$globalgreen.lag
                            ,newdata$gdp.lag
                            ,newdata$incumbent
                            ,newdata$incumbent.emphasis.lag
                            ,newdata$prevvote
                            ,newfes)

truesocdemscenario <- truesocdemscenario[,!is.na(coefs)]

# change actual issue emphasis for conservatives in Sweden to fake value
newdata$issue[newcmp$countryname=="Sweden" & newcmp$parfam==60 & newcmp$date==201009] <- median(prob_base)
# use these inputs to predict other countries (Social Democratic parties)
fakesocdemscenario <- cbind(1,newdata$issue.lag
                            ,newW.f.win %*% newdata$issue
                            ,newW.f.lose %*% newdata$issue
                            ,newW.d.win %*% newdata$issue
                            ,newW.d.lose %*% newdata$issue
                            ,newdata$vsgreen.lag
                            ,newdata$vsgreen.lag2
                            ,newdata$globalgreen.lag
                            ,newdata$gdp.lag
                            ,newdata$incumbent
                            ,newdata$incumbent.emphasis.lag
                            ,newdata$prevvote
                            ,newfes)

fakesocdemscenario <- fakesocdemscenario[,!is.na(coefs)]

dim(truesocdemscenario)

# 3. y with true and fake input
xb_all_true <- truesocdemscenario%*%coefs[!is.na(coefs)]
xb_all_fake <- fakesocdemscenario%*%coefs[!is.na(coefs)]
# get from log odds to probabilities (true and fake)
odds_all_true <- exp(xb_all_true)
odds_all_fake <- exp(xb_all_fake)
prob_all_true <- odds_all_true/(1+odds_all_true)
prob_all_fake <- odds_all_fake/(1+odds_all_fake)

cbind(prob_all_true,prob_all_fake)

tmp <- cbind(newcmp$country,newcmp$date,newcmp$party,prob_all_fake-prob_all_true)
colnames(tmp) <- c("country","date","party","change")
length(unique(tmp[,"party"]))
# remove sweden
unique(newcmp$country[newcmp$countryname=="Sweden"])
tmp <- tmp[tmp[,"country"]!=11,]
unique(cmp$countryname[cmp$country==31 |cmp$country==33])

# mean for each country
ch_country <- cbind(unique(tmp[,"country"]),NA)
for(i in unique(tmp[,"country"])){
  ch_country[match(i,unique(tmp[,"country"])),2] <- mean(tmp[tmp[,"country"]==i,"change"])
}
ch_country <- as.data.frame(ch_country
                            ,row.names=unique(newcmp$countryname[newcmp$country %in% ch_country[,1]]))
ch_country$region <- rownames(ch_country)
ch_country$region[ch_country$region=="United Kingdom"] <- "UK"
newcmp[newcmp$country==31,1:10]
newcmp[newcmp$country==33,1:10]
newcmp[newcmp$country==32,1:10] # Italy
newcmp[newcmp$country==97,1:10] # Slovenia

100/(data$issue[cmp$party==32061 & cmp$date==201302]*100)*ch_country$V2[ch_country$region=="Italy"]

data$issue[cmp$party==97330 & cmp$date==201112]
100/(data$issue[cmp$party==97330 & cmp$date==201112]*100)*ch_country$V2[ch_country$region=="Slovenia"]

######
# MAP
######
library(dplyr)
library(ggplot2)
# Retrievethe map data
world <- map_data("world")
#maps$issue <- NA

tojoin <- as.data.frame(matrix(
  nrow = length(table(world$region)),
  ncol = 1,
  NA,
  dimnames = list(names(table(world$region)),NA)
))
tojoin$region <- rownames(tojoin)

all(ch_country$region %in% tojoin$region)

all <- merge(tojoin,ch_country,by="region",all.x=T)
colnames(all)
all <- all[,!is.na(colnames(all))]
colnames(all) <- c("region","country","issue")
all$issue <- all$issue*100

maps <- inner_join(world,all,by="region")
maps2 <- maps[maps$region %in% ch_country$region,]
countries <- unique(cmp$countryname)
countries[countries=="United Kingdom"] <- "UK"
all(countries %in% maps$region)
maps3 <- maps[maps$region %in% countries,]

maps4 <- maps[maps$region=="Sweden",]

# PLOT
library(tikzDevice)
tikz(paste0(getwd(),"/BJPolS Submission/1. Revision/Revised Manuscript/map.tex"),width=5,height=5)
draw <- ggplot(maps, aes(x = long, y = lat)) + theme(
  panel.background = element_rect(fill = "white",
                                  color = NA),
  panel.grid = element_blank(),
  axis.text.x = element_blank(),
  axis.text.y = element_blank(),
  axis.ticks = element_blank(),
  axis.title.x = element_blank(),
  axis.title.y = element_blank()
)

draw <- draw + coord_fixed(xlim = c(-9, 32.7),
                           ylim = c(36, 70),
                           ratio = 1.5)

draw <- draw + geom_polygon(data = maps,
                            aes(x = long,
                                y = lat,
                                group = group),
                            fill="white",
                            color = "black")

draw <- draw + geom_polygon(data = maps3,
                            aes(x = long,
                                y = lat,
                                group = group),
                            fill="grey",
                            color = "black")

draw <- draw + geom_polygon(data = maps2,
                            aes(fill = issue,
                                x = long,
                                y = lat,
                                group = group)
                            )
draw <- draw + theme(legend.position = "bottom"
                     ,legend.title = element_blank()
                     ,legend.text = element_text(size=8)
                     ,legend.key.width = unit(1, 'cm')
                     ,legend.key.height = unit(.3, 'cm')
                     ,legend.spacing=unit(.5, 'cm')
                     )
draw
dev.off()









###### ALTERNATIVE
countries <- unique(cmp$countryname)
countries[countries=="United Kingdom"] <- "UK"
# Retrievethe map data
europe <- map_data("world", region=countries)
#maps$issue <- NA

tojoin <- as.data.frame(matrix(
  nrow = length(table(europe$region)),
  ncol = 1,
  NA,
  dimnames = list(names(table(europe$region)),NA)
))
tojoin$region <- rownames(tojoin)

all(newcmp$countryname %in% tojoin$region)

all <- merge(tojoin,ch_country,by="region",all.x=T)
colnames(all)
all <- all[,!is.na(colnames(all))]
colnames(all) <- c("region","country","issue")
all$issue <- all$issue*100

maps <- inner_join(europe,all,by="region")

# PLOT
library(tikzDevice)
tikz(paste0(getwd(),"/Working Paper/map.tex"),width=4.5,height=5)
par(mar=c(3.5,5,0.1,2))
draw <- ggplot(maps, aes(x = long, y = lat)) + theme(
  panel.background = element_rect(fill = "white",
                                  color = NA),
  panel.grid = element_blank(),
  axis.text.x = element_blank(),
  axis.text.y = element_blank(),
  axis.ticks = element_blank(),
  axis.title.x = element_blank(),
  axis.title.y = element_blank()
)

draw <- draw + geom_polygon(data = maps,
                            aes(fill = issue,
                                x = long,
                                y = lat,
                                group = group),
                            color = "white")
draw
dev.off()














##############################
# Figures for Presentation
##############################
# define colors for figures
mannheimBlue1 <- rgb(0,.175,.35, alpha=.9)
mannheimBlue2 <- rgb(0,.175,.35, alpha=.45)

library(tikzDevice)

# Average Marginal Effects (AME) Plot
tikz(paste0(getwd(),"/MPSA 2018/Presentation/pres_ame.tex"),width=4.5,height=3)
par(mar=c(3.5,4.9,3,2),mgp=c(1.5,.7,0))
plot(x=ame[,"Estimate"],y=c(4,3,2,1),ylim=c(0,5),xlim=c(-.2,.55),pch=4,axes=F,ann=F,col=mannheimBlue1)
lines(y=c(4,4),x=c(ame["f.bloc.win","lowerCI"],ame["f.bloc.win","upperCI"]),col=mannheimBlue1)
lines(y=c(3,3),x=c(ame["f.bloc.lose","lowerCI"],ame["f.bloc.lose","upperCI"]),col=mannheimBlue1)
lines(y=c(2,2),x=c(ame["d.bloc.win.lag","lowerCI"],ame["d.bloc.win.lag","upperCI"]),col=mannheimBlue1)
lines(y=c(1,1),x=c(ame["d.bloc.lose.lag","lowerCI"],ame["d.bloc.lose.lag","upperCI"]),col=mannheimBlue1)
text(x=c(ame[1,2],ame[2,2]-.02,.04,.04),y=c(4,3,2,1),labels=round(ame[,2],3)
     ,pos=3,cex=.7,col=mannheimBlue1)
abline(v=0,lty=2,col="red",lwd=2)
axis(1,c(-1,-.2,-.1,0,.1,.2,.3,.4,.5,1),labels=c("","-0.2","-0.1","0","0.1","0.2","0.3","0.4","0.5","")
     ,col.axis=mannheimBlue1,col=mannheimBlue1, cex.axis=.7)
axis(2,c(-1,1,2,3,4,6),labels=c("","\\begin{tabular}{c} Domestic\\\\ Loser \\end{tabular}"
                                ,"\\begin{tabular}{c} Domestic\\\\ Winner \\end{tabular}"
                                ,"\\begin{tabular}{c} Foreign\\\\ Loser \\end{tabular}"
                                ,"\\begin{tabular}{c} Foreign\\\\ Winner \\end{tabular}","")
     ,las=1,col.axis=mannheimBlue1,col=mannheimBlue1, cex.axis=.7)
mtext("Effect Size",1,line=2,col=mannheimBlue1)
mtext("Average Marginal Short-Term Effects",3,line=1,col=mannheimBlue1,font=2)
box("plot",lwd=2,col=mannheimBlue1)
dev.off()


# Average Marginal Effects (AME) Plot WITH P-VALUE FOR FOREIGN DIFFERENCE
tikz(paste0(getwd(),"/MPSA 2018/Presentation/pres_ame2.tex"),width=4.5,height=3)
par(mar=c(3.5,4.9,3,2),mgp=c(1.5,.7,0))
plot(x=ame[1:2,"Estimate"],y=c(4,3),ylim=c(0,5),xlim=c(-.2,.55),pch=4,axes=F,ann=F,col=mannheimBlue1)
lines(y=c(4,4),x=c(ame["f.bloc.win","lowerCI"],ame["f.bloc.win","upperCI"]),col=mannheimBlue1)
lines(y=c(3,3),x=c(ame["f.bloc.lose","lowerCI"],ame["f.bloc.lose","upperCI"]),col=mannheimBlue1)
text(x=c(ame[1,2],ame[2,2]-.02),y=c(4,3),labels=round(ame[1:2,2],3)
     ,pos=3,cex=.7,col=mannheimBlue1)
abline(v=0,lty=2,col="red",lwd=2)
text(x=0.4,y=1,labels="\\begin{tabular}{c} $H_A$: \\\\ \\begin{tabular}{c} Foreign\\\\ Loser \\end{tabular} $<$ \\begin{tabular}{c} Foreign\\\\ Winner \\end{tabular} \\\\ $(p = 0.003)$ \\end{tabular}",col=mannheimBlue1,cex=.7)
axis(1,c(-1,-.2,-.1,0,.1,.2,.3,.4,.5,1),labels=c("","-0.2","-0.1","0","0.1","0.2","0.3","0.4","0.5","")
     ,col.axis=mannheimBlue1,col=mannheimBlue1, cex.axis=.7)
axis(2,c(-1,1,2,3,4,6),labels=c("",""
                                ,""
                                ,"\\begin{tabular}{c} Foreign\\\\ Loser \\end{tabular}"
                                ,"\\begin{tabular}{c} Foreign\\\\ Winner \\end{tabular}","")
     ,las=1,col.axis=mannheimBlue1,col=mannheimBlue1, cex.axis=.7)
mtext("Effect Size",1,line=2,col=mannheimBlue1)
mtext("Average Marginal Short-Term Effects",3,line=1,col=mannheimBlue1,font=2)
box("plot",lwd=2,col=mannheimBlue1)
dev.off()




# Average Marginal Effects (AME) Plot WITH P-VALUE FOR FOREIGN AND DOMESTIC DIFFERENCE
tikz(paste0(getwd(),"/MPSA 2018/Presentation/pres_ame3.tex"),width=4.5,height=3)
par(mar=c(3.5,4.9,3,2),mgp=c(1.5,.7,0))
plot(x=ame[3:4,"Estimate"],y=c(2,1),ylim=c(0,5),xlim=c(-.2,.55),pch=4,axes=F,ann=F,col=mannheimBlue1)
lines(y=c(2,2),x=c(ame["d.bloc.win.lag","lowerCI"],ame["d.bloc.win.lag","upperCI"]),col=mannheimBlue1)
lines(y=c(1,1),x=c(ame["d.bloc.lose.lag","lowerCI"],ame["d.bloc.lose.lag","upperCI"]),col=mannheimBlue1)
text(x=c(.04,.04),y=c(2,1),labels=round(ame[3:4,2],3)
     ,pos=3,cex=.7,col=mannheimBlue1)
abline(v=0,lty=2,col="red",lwd=2)
text(x=0.4,y=4,labels="\\begin{tabular}{c} $H_A$: \\\\ \\begin{tabular}{c} Domestic\\\\ Loser \\end{tabular} $\\neq$ \\begin{tabular}{c} Domestic\\\\ Winner \\end{tabular} \\\\ $(p = 0.631)$ \\end{tabular}",col=mannheimBlue1,cex=.7)
axis(1,c(-1,-.2,-.1,0,.1,.2,.3,.4,.5,1),labels=c("","-0.2","-0.1","0","0.1","0.2","0.3","0.4","0.5","")
     ,col.axis=mannheimBlue1,col=mannheimBlue1, cex.axis=.7)
axis(2,c(-1,1,2,3,4,6),labels=c("","\\begin{tabular}{c} Domestic\\\\ Loser \\end{tabular}"
                                ,"\\begin{tabular}{c} Domestic\\\\ Winner \\end{tabular}"
                                ,""
                                ,"","")
     ,las=1,col.axis=mannheimBlue1,col=mannheimBlue1, cex.axis=.7)
mtext("Effect Size",1,line=2,col=mannheimBlue1)
mtext("Average Marginal Short-Term Effects",3,line=1,col=mannheimBlue1,font=2)
box("plot",lwd=2,col=mannheimBlue1)
dev.off()


# Marginal Effects Plot Greenvote
est <- apply(gvote,2,mean)
low <- apply(gvote,2,quantile,probs=.025)
up <- apply(gvote,2,quantile,probs=.975)
tikz(paste0(getwd(),"/MZES Workshop/Presentation/pres_greenvote.tex"),width=4.5,height=3)
par(mar=c(3.5,4.9,3,2))
plot(x=greenvote,y=est,ylim=c(-.25,.25),xlim=c(0.5,15),type="l",lwd=2.5,axes=F,ann=F,col=mannheimBlue1)
lines(greenvote,low,col=mannheimBlue1)
lines(greenvote,up,col=mannheimBlue1)
abline(h=0,lty=2,col="red",lwd=2)
rug(data$vsgreen.lag,col=mannheimBlue2)
axis(1,c(-10,0,5,10,15,20),labels=c("","0","5","10","15",""),col.axis=mannheimBlue1,col=mannheimBlue1)
axis(2,c(-1,-.2,-.1,0,.1,.2,1),labels=c("","-0.2","-0.1","0","0.1","0.2","")
     ,las=1,col.axis=mannheimBlue1,col=mannheimBlue1)
mtext("Green Vote Share at t-1",1,line=2,col=mannheimBlue1)
mtext("Marginal Effect",2,line=2.5,col=mannheimBlue1)
mtext("Marginal Effect of Green Parties' Electoral Support",3,line=1,col=mannheimBlue1,font=2)
box("plot",lwd=2,col=mannheimBlue1)
dev.off()


#








#####
# NOT USED!!!
#####

##############
# SIMULATION
##############
set.seed(123)
# Extract information for Simulations
coefs <- m5$coefficients[1:13]
vcov <- vcov(m5)[1:13,1:13]
nsim <- 10000
sims <- mvrnorm(nsim,mu=coefs,Sigma=vcov)
# Things for spatial AMEs
greenvote <- seq(from=0, to=17,by=.1)
ame.f.bloc.win <- matrix(NA,nrow=nsim,ncol=length(greenvote))
for(i in 1:nsim){
  for(g in 1:length(greenvote)){
    # Marginal Effect Interaction
    scenario <- cbind(1,data$issue.lag
                      ,greenvote[g]*data$f.bloc.win
                      ,greenvote[g]*data$f.bloc.lose
                      ,data$f.bloc.win
                      ,data$f.bloc.lose
                      ,data$d.bloc.win.lag
                      ,data$d.bloc.lose.lag
                      ,greenvote[g],greenvote[g]^2
                      ,data$gdp.lag,data$incumbent
                      ,data$prevvote)
    # xb
    xb <- scenario %*% sims[i,]
    # get probabilities
    p <- exp(xb)/(1+exp(xb))
    
    # AME of spatial coefficients
    ame.f.bloc.win[i,g] <- 1/nrow(data) * sum((sims[i,"f.bloc.win"]*s.f.bloc.win + sims[i,"I(vsgreen.lag * f.bloc.win)"]*s.f.bloc.win * greenvote[g])*p*(1-p))
  }
}

# Average Marginal Effects
ame <- matrix(NA,nrow=length(greenvote),ncol=3)
colnames(ame) <- c("lowerCI","Estimate","upperCI")
ame[,"Estimate"] <- apply(ame.f.bloc.win,2,mean)
ame[,"lowerCI"] <- apply(ame.f.bloc.win,2,quantile, probs=.025)
ame[,"upperCI"] <- apply(ame.f.bloc.win,2,quantile, probs=.975)


tikz(paste0(getwd(),"/BJPolS Submission/1. Revision/Supplementary Materials/ame_cond.tex"),width=5,height=3)
#pdf(paste0(getwd(),"/ame_cond.pdf"),width=5,height=3)
par(mar=c(3.5,4.9,0.1,2))
plot(x=greenvote,y=ame[,"Estimate"],ylim=c(-1,2),xlim=c(0.5,15),type="l",lwd=2.5,axes=F,ann=F)
lines(greenvote,ame[,"lowerCI"])
lines(greenvote,ame[,"upperCI"])
abline(h=0,lty=2)
rug(data$vsgreen.lag,col="gray70")
axis(1,c(-10,0,5,10,15,20),labels=c("","0","5","10","15",""))
axis(2, las=1)
mtext("Green Vote Share at t-1",1,line=2.4)
mtext("Average Marginal Short-Term Effect\n (Foreign Winner)",2,line=3)
box("plot",lwd=2)
dev.off()




