#####################
REPLICATION MATERIALS
#####################

AUTHORS: Sebastian Juhl and Laron K. Williams
ARTICLE: "Learning at Home and Abroad: How Competition Conditions the Diffusion of Party Strategies"
JOURNAL: British Journal of Political Science
UPDATED: October 21, 2020
CONTACT: sebastian.juhl@gess.uni-mannheim.de
http://www.sebastianjuhl.com


INSTRUCTIONS:
The script "Results.R" contains the main replication code. It replicates all figures and tables presented in the article. The script "Appendix.R" replicates all results presented in the Supplementary Materials. The output will be stored in the subfolder "Output" which each of the R script creates automatically in case it is not provided.


SOFTWARE:
R version 4.0.2 (2020-06-22)
Platform: x86_64-apple-darwin17.0 (64-bit)
Running under: macOS Catalina 10.15.7

The following R packages were used to perform the analysis:
package:	version:
--------------------
- ggplot		2_3.3.2
- dplyr			1.0.2
- MASS			7.3-51.6



TABLE OF CONTENTS:
- Main Folder:
	1) "Results.R": main R-script for replicating all figures and table reported in the article.
	2) "Appendix.R": supplementary R-script for the analyses in the Supplementary Materials.
	
	- Subfolder "Data"
		3) "Juhl_Williams_Data.RData": the dataset.
		4) "Matrices.Rdata": the connectivity matrices (based on party family membership).
		5) "Matrices_bloc.Rdata": additional connectivity matrices (based on party blocs) necessary to replicate the results in Supplementary Materials B.
	- Subfolter "Output"
		6) "Table_2.csv": Table 2
		7) "Table_3.csv": Table 3
		8) "Figure_1.pdf": Figure 1
		9) "Figure_2.pdf": Figure 2
