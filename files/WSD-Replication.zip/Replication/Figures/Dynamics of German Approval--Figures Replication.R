#######################################################################################
### R file to create the figure for "Relaxing the Constant Economic Vote Restriction: Economic Evaluations and Party Support in Germany", Laron K. Williams, Mary Stegmaier, and Marc Debus.
###
### Created: 5-19-15
###
#######################################################################################

library(foreign)
library(ggplot2)
library(lattice)
library(fields)

# Set up working directory
#setwd("")

#######################################################################################
### Lag Distributions
#######################################################################################
d = read.csv("Lag.csv")
d1.1 = subset(d, party == "CDU" & govt == 1)
d1.3 = subset(d, party == "CDU" & govt == 3)
d2.1 = subset(d, party == "SPD" & govt == 1)
d2.2 = subset(d, party == "SPD" & govt == 2)
d2.3 = subset(d, party == "SPD" & govt == 3)
d3.2 = subset(d, party == "FDP" & govt == 2)
d3.3 = subset(d, party == "FDP" & govt == 3)
d4.2 = subset(d, party == "G" & govt == 2)
d4.3 = subset(d, party == "G" & govt == 3)


# CDU as Chancellor
cdu_ch <- ggplot() + geom_point(data=subset(d, party == "CDU" & govt == 1), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "CDU" & govt == 1), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("CDU") + xlab("") + ggtitle("Chancellor")
cdu_ch <- cdu_ch + scale_x_discrete(limits=c(1, 2, 3)) + theme(axis.title.y = element_text(angle=0)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
cdu_ch

# CDU as Coalition Partner
cdu_c <- ggplot(data = subset(d, party == "CDU" & govt == 1), aes(x=t, y=d)) + geom_blank() + ggtitle("Coalition Partner") + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_blank(), axis.ticks = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank()) + xlab("") + ylab("")
cdu_c

# CDU as Opposition Party
cdu_o <- ggplot() + geom_point(data=subset(d, party == "CDU" & govt == 3), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "CDU" & govt == 3), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("") + xlab("") + ggtitle("Opposition")
cdu_o <- cdu_o + scale_x_discrete(limits=c(1, 2, 3)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
cdu_o

# SPD as Chancellor
spd_ch <- ggplot() + geom_point(data=subset(d, party == "SPD" & govt == 1), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "SPD" & govt == 1), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("SPD") + xlab("") + ggtitle("")
spd_ch <- spd_ch + scale_x_discrete(limits=c(1, 2, 3)) + theme(axis.title.y = element_text(angle=0)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
spd_ch

# SPD as Coalition Partner
spd_c <- ggplot() + geom_point(data=subset(d, party == "SPD" & govt == 2), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "SPD" & govt == 2), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("") + xlab("")
spd_c <- spd_c + scale_x_discrete(limits=c(1, 2, 3)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
spd_c

# SPD as Opposition
spd_o <- ggplot() + geom_point(data=subset(d, party == "SPD" & govt == 3), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "SPD" & govt == 3), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("") + xlab("") + ggtitle("")
spd_o <- spd_o + scale_x_discrete(limits=c(1, 2, 3)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
spd_o

# FDP as Chancellor
fdp_ch <- ggplot(data = subset(d, party == "FDP" & govt == 2), aes(x=t, y=d)) + geom_blank() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_blank(), axis.ticks = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank()) + xlab("") + ylab("") + ylab("FDP") + theme(axis.title.y = element_text(angle=0))
fdp_ch

# FDP as Coalition Partner
fdp_c <- ggplot() + geom_point(data=subset(d, party == "FDP" & govt == 2), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "FDP" & govt == 2), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("") + xlab("") + ggtitle("")
fdp_c <- fdp_c + scale_x_discrete(limits=c(1, 2, 3)) + theme(axis.title.y = element_text(angle=0)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
fdp_c

# FDP as Opposition
fdp_o <- ggplot() + geom_point(data=subset(d, party == "FDP" & govt == 3), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "FDP" & govt == 3), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("") + xlab("") + ggtitle("")
fdp_o <- fdp_o + scale_x_discrete(limits=c(1, 2, 3)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
fdp_o

# Greens as Chancellor
g_ch <- ggplot(data = subset(d, party == "G" & govt == 2), aes(x=t, y=d)) + geom_blank() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_blank(), axis.ticks = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank()) + xlab("") + ylab("Greens") + theme(axis.title.y = element_text(angle=0))
g_ch

# Greens as Coalition Partner
g_c <- ggplot() + geom_point(data=subset(d, party == "G" & govt == 2), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "G" & govt == 2), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("") + xlab("t") + ggtitle("")
g_c <- g_c + scale_x_discrete(limits=c(1, 2, 3)) + theme(axis.title.y = element_text(angle=0)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
g_c

# Greens as Opposition
g_o <- ggplot() + geom_point(data=subset(d, party == "G" & govt == 3), aes(x=t, y=d)) + geom_linerange(data=subset(d, party == "G" & govt == 3), aes(x=t, ymin=dlo.95, ymax=dhi.95)) + geom_hline(yintercept=0, linetype="dashed") + ylab("") + xlab("t") + ggtitle("")
g_o <- g_o + scale_x_discrete(limits=c(1, 2, 3)) + theme(plot.margin=unit(c(0,0.01,0,0), units="npc"))
g_o

# Combine the nine plots onto one figure
pdf(file="lagdist.pdf", family="Times")
grid.newpage()
pushViewport(viewport(layout = grid.layout(4,3)))

vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(cdu_ch, vp = vplayout(1, 1))
print(cdu_c, vp = vplayout(1, 2))
print(cdu_o, vp = vplayout(1, 3))
print(spd_ch, vp = vplayout(2, 1))
print(spd_c, vp = vplayout(2, 2))
print(spd_o, vp = vplayout(2, 3))
print(fdp_ch, vp = vplayout(3, 1))
print(fdp_c, vp = vplayout(3, 2))
print(fdp_o, vp = vplayout(3, 3))
print(g_ch, vp = vplayout(4, 1))
print(g_c, vp = vplayout(4, 2))
print(g_o, vp = vplayout(4, 3))
dev.off()
