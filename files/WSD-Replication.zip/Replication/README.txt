***************************************************************
*** This folder contains all of the files necessary to replicate the empirical results in "Relaxing the Constant Economic Vote Restriction" by Laron K. Williams, Mary Stegmaier and Mard Debus.
***
*** Questions?  Contact Laron K. Williams, williamslaro@missouri.edu
***************************************************************

The following files are in the zipped folder:
1) Data (Stata): "German Party Approval.dta"

2) Command File (Stata): "Dynamics of German Approval--Replication.do"

3) Copy of Results (Stata): "Dynamics of German Approval--Replication.smcl"

4) Command Figures File (R): "Dynamics of German Approval--Figures Replication.R"

5) Data for Lag Distributions (Excel): "Lag.csv"

6) Figure 2 (pdf): "lagdist.pdf"