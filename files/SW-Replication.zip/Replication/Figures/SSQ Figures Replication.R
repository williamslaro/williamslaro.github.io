##=============================================================================#
## Code to reproduce the figures found in Sagarzazu and Williams "Making and Breaking Party Leaders", Social Science Quarterly
## 
## Created : 7-6-16
## Modified: 12-22-16
##=============================================================================#

rm(list=ls())
require(lattice)
require(MASS)
require(ggplot2)
require(gridBase)
require(gridExtra)
library(foreign)
library(reshape2)
library(scales)
library(fields)

# Set up working directory


###############################################################################################
## Figure 1: salience of economic and social problems and evaluations of the national economy
###############################################################################################
m <- read.dta("Figures/MIP.dta", convert.underscore=TRUE)
e <- read.dta("Figures/evals.dta", convert.underscore=TRUE)

mip <- ggplot(data = m, aes(x=ts, y=mip, group=problem)) 
mip <- mip + geom_line(aes(linetype = problem), size=1.25)
mip <- mip + ylab("Most Important Problem (%)") + xlab("")
mip <- mip + scale_x_continuous(breaks=c(480, 528, 576, 624, 672), labels=c("2000", "2004", "2008", "2012", "2016"))
mip <- mip + theme_bw() + theme(legend.title=element_blank(), legend.position="bottom") 

ev <- ggplot(data = e, aes(x=ts, y=retnat.avg)) + geom_line()
ev <- ev + ylab("Average Retrospective Evaluations (3=Worse)") + xlab("")
ev <- ev + scale_x_continuous(breaks=c(480, 528, 576, 624, 672), labels=c("2000", "2004", "2008", "2012", "2016"))
ev <- ev + theme_bw()

# Combine the two plots onto one figure
grid.newpage()
pushViewport(viewport(layout = grid.layout(2,1)))

vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(mip, vp = vplayout(1, 1))
print(ev, vp = vplayout(2, 1))


###############################################################################################
## Figure 2: vote intention for PP and PSOE, 1998-2016
###############################################################################################
s <- read.dta("Figures/support.dta", convert.underscore=TRUE)

v <- ggplot(data=s, aes(x=ts, y=support, group=party))
v <- v + geom_line(aes(linetype = party), size=1.25)
v <- v + ylab("Vote Intention") + xlab("")
v <- v + scale_x_continuous(breaks=c(480, 528, 576, 624, 672), labels=c("2000", "2004", "2008", "2012", "2016"))
v <- v + theme_bw() + theme(legend.title=element_blank(), legend.position="bottom") 
v



###############################################################################################
## Figure 3: dynamic simulations of the effects of debates on vote intention (%)
###############################################################################################
ds = read.dta("Figures/Dynamic Simulations.dta")

ds.pp = subset(ds, party == "PP")
ds.psoe = subset(ds, party == "PSOE")

p <- ggplot(data=ds, aes(t, d)) + geom_point() + geom_linerange(aes(x=t, ymin=dlo90, ymax=dhi90))
p <- p + facet_grid(party ~ debate)
p <- p + geom_hline(yintercept=0, linetype="dashed")
p <- p + ylab("Vote Intention (%)") + xlab("")
p

