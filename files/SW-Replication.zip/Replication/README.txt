
*** This folder contains all of the files needed to replicate Sagarzazu and Williams �Making and Breaking Party Leaders?�, Social Science Quarterly
*** Please email williamslaro@missouri.edu if you have any questions.

The folder contains the following files:
1) SSQ�Replication.do: Stata command file that contains all of the code necessary to create the datasets for figures, estimate the models, and generate quantities of interest shown in the manuscript.
2) Spanish Barometer 1998-2016�Aggregate.dta: Stata data set that contains all of the aggregate percentages for the Spanish barometer surveys, 1998-2016.
3) SSQ Figures Replication.R: R script file containing the code to create Figures 1-3.
4) Support.dta, MIP.dta, and evals.dta: Stata data sets (created in SSQ�Replication.do) that take the aggregate dataset and extract the variables needed to produce Figures 1 and 2.
5) Macro.dta and Dynamic Simulations.dta: Stata data sets (created in SSQ�Replication.do) that contain the quantities of interest and are used to produce Figure 3.  
6) SSQ�Replication.smcl: Stata log file containing the exact replication of the results.
