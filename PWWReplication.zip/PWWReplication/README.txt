This zipped folder contains all of the files needed to replicate the results and figures in Palmer, Whitten and Williams (2013, Electoral Studies).

The folder includes the following files:

1) PWW.dta: Stata data set used to estimate all the models.
2) PalmerWhittenWilliams--Replication.do: Stata do file that replicates the four SUR models, produces stationarity tests, generates substantive effects, and produces the two dynamic simulations.
3) Electoral Studies--Stationarity Tests.smcl: Stata log file that shows the stationarity tests.
4) SUR Substantive Effects.smcl: Stata log file that shows the substantive effects shown in Table 2.
5) hi_inf.dta and low_unem.dta: Stata data sets that are produced in the do file, and are used to produce the dynamic simulations (Figures 1 and 2, respectively).

Please email me if you have any questions: williamslaro@missouri.edu

