################################################################################
### R file to create the higher-order weights matrices for the WWW JoP project
###
### Created: 5-19-15
### Modified:
###
################################################################################

library(sna)
library(foreign)
library(gdata)

### 200 x 200 contiguity weights matrix
set.seed(12345)		### Set the seed

W <- rgraph(200, m=1, tprob=0.1, mode="graph", diag=FALSE)
W2 <- neighborhood(W, 2)
W3 <- neighborhood(W, 3)
W4 <- neighborhood(W, 4)

Wrs <- make.stochastic(W, mode="row")
W2rs <- make.stochastic(W2, mode="row")
W3rs <- make.stochastic(W3, mode="row")
W4rs <- make.stochastic(W4, mode="row")

W_200 <- as.data.frame(W)
W2_200 <- as.data.frame(W2)
W3_200 <- as.data.frame(W3)
W4_200 <- as.data.frame(W4)

Wrs_200 <- as.data.frame(Wrs)
W2rs_200 <- as.data.frame(W2rs)
W3rs_200 <- as.data.frame(W3rs)
W4rs_200 <- as.data.frame(W4rs)

write.dta(W_200, file="W_200.dta")
write.dta(W2_200, file="W2_200.dta")
write.dta(W3_200, file="W3_200.dta")
write.dta(W4_200, file="W4_200.dta")

write.dta(Wrs_200, file="W_200rs.dta")
write.dta(W2rs_200, file="W2_200rs.dta")
write.dta(W3rs_200, file="W3_200rs.dta")
write.dta(W4rs_200, file="W4_200rs.dta")