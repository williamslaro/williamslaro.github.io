These files contain the replication materials for "Flexible Election Timing and International Conflict", International Studies Quarterly.

There are two Stata do files, one for each stage in the empirical modeling.  The first do file, "Election Timing--Election Results--Replication.do", must be ran first.  It uses the "Election Timing.dta" data set and creates the necessary files for the second stage.

In the second stage of the empirical modeling, use the "Election Timing--Conflict--Replication.do" file to estimate the models of conflict initiation, generate descriptive statistics, and substantive effects.

There are two actions in the second file that take 9-10 hours, so the user can generate these files once and then "comment" out those commands so that they can tweak the substantive effects commands without having to do the time-consuming commands again.

