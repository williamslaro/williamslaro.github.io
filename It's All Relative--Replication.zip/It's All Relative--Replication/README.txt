****************************************************************************************************
This folder contains all of the necessary files to replicate the results shown and discussed in 
"It's All Relative: Spatial Positioning of Parties and Ideological Shifts", Laron K. Williams, European Journal of Political Research.
****************************************************************************************************

The folder contains the following files:
1) "It's All Relative--Additional Materials.pdf": additional materials file containing additional analyses discussed but not presented in the manuscript.
2) "It's All Relative--Replication.do": Stata do file containing the necessary commands to replicate the analyses in the manuscript.
3) "It's All Relative--Replication.smcl": Stata log file (.smcl) containing an exact repliaction of the analyses.
4) "It's All Relative.dta": Stata data set needed to replicate the results.
5) Three weights matrices used in the empirical analyses: "proximity_t2_200_tm2.dta", "neighbor_proximity_t2_200_tm2.dta", and "family_proximity_t2_200_tm2.dta".
6) "It's All Relative--Figure Replication.R": R file used to produce Figures 1 and 3.
7) "shift.csv": comma-separated version (.csv) file used in the creation of Figure 3.

