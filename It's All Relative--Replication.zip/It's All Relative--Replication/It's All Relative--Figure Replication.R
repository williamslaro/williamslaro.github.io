################################################################################
################################################################################
##
## Code to replicate the figures for "It's All Relative: Spatial Positioning of Parties and Ideological Shifts", European Journal of Political Research.
##
## Created: 6-26-14
## 
################################################################################
################################################################################

library(foreign)

# Establish working directory
#setwd("")

################################################################################
### Figure 1: Four Scenarios of Ideological Movement that Result in an Average Party Shift Value of 0.
################################################################################

# Centripetal
xlim <- c(-55,55)    # x-axis range
ylim <- c(-55,55)  # y-axis range

x <- seq(0,100,by=1)
cexp <- 0.8

par(fig=c(0,0.5,0.52,1),mar=c(2,3,1,3))
plot(x, x, xlim=xlim, ylim=ylim, ann=F, type="n",axes=FALSE)

atx <- c(-50,-25,0,25,50)
aty <- c(-55,55)
labaty <- c("L","R")

axis(side=2, cex=.5, at=atx)
axis(side=1,cex=0.5, at=aty, lab=labaty)
mtext("Left-Right Position", 2, line = 2, cex=cexp)
mtext("Centripetal", 3, line = -.75, cex=1.1)

segments(0,-55,0,50,lty="dotted",col="black")
points(0,0, pch=19, cex=1)
text(25,0, "Focal Party", cex=0.8, font=2) 

arrows(0,50,-35,50,length=0.1,lwd=2)
arrows(0,25,-10,25,length=0.1,lwd=2)
arrows(0,-25,10,-25,length=0.1,lwd=2)
arrows(0,-50,35,-50,length=0.1,lwd=2)

# Centrifugal
xlim <- c(-55,55)    # x-axis range
ylim <- c(-55,55)  # y-axis range

x <- seq(0,100,by=1)
cexp <- 0.8

par(fig=c(0.5,1,0.52,1),mar=c(2,3,1,3), new=TRUE)
plot(x, x, xlim=xlim, ylim=ylim, ann=F, type="n",axes=FALSE)

atx <- c(-50,-25,0,25,50)
aty <- c(-55,55)
labaty <- c("L","R")

axis(side=2, cex=.5, at=atx)
axis(side=1,cex=0.5, at=aty, lab=labaty)
mtext("Centrifugal", 3, line = -.75, cex=1.1)

segments(0,-55,0,50,lty="dotted",col="black")
points(0,0, pch=19, cex=1)
text(25,0, "Focal Party", cex=0.8, font=2) 

arrows(0,50,35,50,length=0.1,lwd=2)
arrows(0,25,10,25,length=0.1,lwd=2)
arrows(0,-25,-10,-25,length=0.1,lwd=2)
arrows(0,-50,-35,-50,length=0.1,lwd=2)

# Niche movement
xlim <- c(-55,55)    # x-axis range
ylim <- c(-55,55)  # y-axis range

x <- seq(0,100,by=1)
cexp <- 0.8

par(fig=c(0,0.5,0.05,0.52),mar=c(1,3,2,3), new=TRUE)
plot(x, x, xlim=xlim, ylim=ylim, ann=F, type="n",axes=FALSE)

atx <- c(-50,-25,0,25,50)
aty <- c(-55,55)
labaty <- c("L","R")

axis(side=2, cex=.5, at=atx)
axis(side=1,cex=0.5, at=aty, lab=labaty)
mtext("Left-Right Position", 2, line = 2, cex=cexp)
mtext("Ideological Shift", 1, line = 1, cex=cexp)
mtext("Niche Moderation", 3, line = -.75, cex=1.1)

segments(0,-55,0,50,lty="dotted",col="black")
points(0,0, pch=19, cex=1)
text(25,0, "Focal Party", cex=0.8, font=2) 

arrows(0,50,-15,50,length=0.1,lwd=2)
arrows(0,25,-15,25,length=0.1,lwd=2)
arrows(0,-25,-15,-25,length=0.1,lwd=2)
arrows(0,-50,45,-50,length=0.1,lwd=2)

# Responsive mainstream parties
xlim <- c(-55,55)    # x-axis range
ylim <- c(-55,55)  # y-axis range

x <- seq(0,100,by=1)
cexp <- 0.8

par(fig=c(0.5,1,0.05,0.52),mar=c(1,3,2,3), new=TRUE)
plot(x, x, xlim=xlim, ylim=ylim, ann=F, type="n",axes=FALSE)

atx <- c(-50,-25,0,25,50)
aty <- c(-55,55)
labaty <- c("L","R")

axis(side=2, cex=.5, at=atx)
axis(side=1,cex=0.5, at=aty, lab=labaty)
mtext("Ideological Shift", 1, line = 1, cex=cexp)
mtext("Responsive Mainstream Parties", 3, line = -.6, cex=1.1)

segments(0,-55,0,50,lty="dotted",col="black")
points(0,0, pch=19, cex=1)
text(25,0, "Focal Party", cex=0.8, font=2) 

arrows(0,50,-10,50,length=0.1,lwd=2)
arrows(0,25,10,25,length=0.1,lwd=2)
arrows(0,-25,10,-25,length=0.1,lwd=2)
arrows(0,-50,-10,-50,length=0.1,lwd=2)




################################################################################
### Figure 3: Predicted Movement of the Focal Party in Response to Shifts by Four Other Parties in the System
################################################################################
b <- read.csv("shift.csv", sep=",", header=TRUE) 

xlim <- c(-60,60)    # x-axis range
ylim <- c(0,2.75)  # y-axis range

cexp <- 0.8

par(fig=c(0,1,0.10,1),mar=c(.25,4,.5,1))
plot(b$x1, b$sxdf, xlim=xlim, ylim=ylim, ann=F, type="n", xaxt="n")

mtext("Predicted Shift by Focal Party", 2, line = 2, cex=cexp)

at <- c(-50,-25,0,25,50)
lab <- c("Party A","Party B","Focal Party","Party C","Party D")

axis(side=1, at=at, labels=lab, cex=.5)
mtext("Left-Right Position", 1, line = 2, cex=cexp)

### AST Prediction: Not Family
points(b$x1, b$ast, pch=19, col="black", cex=1.5)

### AST Prediction: Family
points(b$x1, b$astf, pch=17, col="black", cex=1.5)

### Spatial-X Distance Prediction: Not Family
points(b$x3, b$sxd, pch=21, col="black", bg="gray", cex=1.5)

### Spatial-X Distance Prediction: Family
points(b$x3, b$sxdf, pch=24, col="black", bg="gray",cex=1.5)

leg.txt <- c("A & S-T", "A & S-T: Family", "S-X: Distance", "S-X: Distance: Family")
col_type <- c("black", "black", "black","black")
pch_type <- c(19,17,21,24)
legend(-32.5, 2.75, leg.txt, col = col_type, pch=pch_type, pt.bg="gray",lty=1, cex=.75, ncol=2)

























